
export enum MasteryLevel {
  EASY = 'Fácil',
  LITERAL = 'Literal',
  MEDIUM = 'Nível Médio',
  HARD = 'Difícil',
  ADVANCED = 'Avançado'
}

export interface Card {
  id: string;
  articleId: string;
  text: string;
  isTrue: boolean;
  explanation: string;
  mastery: MasteryLevel;
  tags: string[];
  isFavorite?: boolean;
}

export interface Note {
  id: string;
  text: string;
  color: 'warm' | 'cold';
  createdAt: number;
}

export interface CardStats {
  attempts: number;
  correctCount: number;
  incorrectCount: number;
  lastResult: 'correct' | 'incorrect';
  lastAnsweredAt: number;
}

export interface Subject {
  id: string;
  title: string;
  description: string;
  createdAt: number;
}

export interface Law {
  id: string;
  subjectId: string; // Vínculo com a matéria (Pasta)
  title: string;
  description: string;
  cards: Card[];
  content?: string;
  htmlContent?: string;
  sourceUrl?: string;
  notes: Note[];
  stats?: Record<string, CardStats>;
  createdAt: number;
}

export interface Theory {
  id: string;
  title: string;
  subject: string;
  contentType: 'html' | 'pdf' | 'docx';
  htmlContent?: string;
  pdfContent?: string;
  hasExternalPdf?: boolean;
  createdAt: number;
}

export interface SessionConfig {
  name: string;
  filters: MasteryLevel[];
  selectedArticles: string[];
  retryIncorrect?: boolean;
  resumeProgress?: boolean;
  onlyFavorites?: boolean;
}

export type AnswerStatus = 'correct' | 'incorrect' | 'unanswered';
