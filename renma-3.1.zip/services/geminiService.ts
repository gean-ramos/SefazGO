import { GoogleGenAI, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const explainCard = async (cardText: string, explanation: string, isTrue: boolean): Promise<string> => {
  try {
    const prompt = `
      Você é um professor de direito tributário especializado em legislação brasileira.
      Analise a seguinte questão de flashcard:
      
      Afirmação: "${cardText}"
      Gabarito: ${isTrue ? 'VERDADEIRO' : 'FALSO'}
      Justificativa Legal: "${explanation}"

      Por favor, explique de forma didática e concisa (máximo 100 palavras) por que a afirmação é ${isTrue ? 'verdadeira' : 'falsa'}, simplificando os termos jurídicos para um estudante.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Não foi possível gerar uma explicação no momento.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Erro ao conectar com o tutor IA. Verifique sua chave de API.";
  }
};

export const generateSpeech = async (text: string, voiceName: string = 'Puck'): Promise<ArrayBuffer | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceName }
            },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) return null;

    // Decode base64 to binary
    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  } catch (error) {
    console.error("Gemini TTS Error:", error);
    return null;
  }
};