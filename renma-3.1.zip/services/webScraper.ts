
// Service to fetch and sanitize external HTML content

export const fetchLawContent = async (url: string): Promise<string> => {
  try {
    // Use 'raw' endpoint to get binary data to handle encoding manually
    // timestamp prevents caching issues
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}&disableCache=${Date.now()}`;
    
    const response = await fetch(proxyUrl);
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }

    const buffer = await response.arrayBuffer();
    
    // 1. Encoding Detection Strategy
    // The requirement is to prioritize ISO-8859-1 (Latin-1) as it is standard for Planalto.
    // However, we must check if the result looks like corrupted UTF-8 (Mojibake).
    
    const decoderIso = new TextDecoder('iso-8859-1');
    let text = decoderIso.decode(buffer);
    
    // 2. Artifact Detection
    // If the file was actually UTF-8 but decoded as ISO, common characters break:
    // ç (C3 A7) -> Ã§
    // ã (C3 A3) -> Ã£
    // é (C3 A9) -> Ã©
    // Ê (C3 8A) -> ÃŠ
    const utf8MojibakePattern = /Ã[§£©®°±ªº¼½¾]|Ã[\x80-\xBF]/;
    
    if (utf8MojibakePattern.test(text)) {
      // Detected UTF-8 artifacts, switch decoder to UTF-8
      const decoderUtf8 = new TextDecoder('utf-8');
      text = decoderUtf8.decode(buffer);
    }

    if (!text || text.trim().length === 0) {
      throw new Error('O conteúdo baixado está vazio.');
    }

    return cleanPlanaltoHtml(text);
  } catch (error) {
    console.error('WebScraper Error:', error);
    throw error;
  }
};

const cleanPlanaltoHtml = (html: string): string => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const body = doc.body;

  // 1. Remove non-content elements
  const tagsToRemove = [
    'script', 'style', 'link', 'meta', 'head', 'title', 'noscript', 
    'img', 'svg', 'iframe', 'object', 'embed', 'canvas',
    'button', 'input', 'select', 'textarea', 'form', 'fieldset',
    'header', 'footer', 'nav', 'aside', 'hr'
  ];
  
  tagsToRemove.forEach(tag => {
    doc.querySelectorAll(tag).forEach(el => el.remove());
  });

  // 2. Flatten structure (Unwrap tables, divs, fonts, spans)
  // We want to keep semantic tags: p, br, h1-h6, strong, b, em, i, u, strike, s
  // We want to remove: table, tr, td, div, span, font, center, a (if not semantic link)

  const allowedTags = ['P', 'BR', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'STRONG', 'B', 'EM', 'I', 'U', 'STRIKE', 'S', 'DEL'];
  
  // Recursive function to extract semantic content
  const cleanNode = (node: Node): Node | null => {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent?.trim() ? node : null;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      const tagName = el.tagName;

      // Create a replacement node or use the current one if allowed
      let newEl: HTMLElement | DocumentFragment;
      let isAllowed = allowedTags.includes(tagName);

      if (isAllowed) {
        newEl = document.createElement(tagName);
      } else {
        // For disallowed tags (div, table, font), we just want their children
        newEl = document.createDocumentFragment();
      }

      // Process children
      let hasContent = false;
      Array.from(node.childNodes).forEach(child => {
        const cleanedChild = cleanNode(child);
        if (cleanedChild) {
          newEl.appendChild(cleanedChild.cloneNode(true));
          hasContent = true;
        }
      });

      // Special handling: Planalto often puts text directly in TDs or DIVs without P tags.
      // If we unwrapped a block element (div, tr, p) and it had text, we might need a line break or p tag
      // to prevent text mashing. 
      // Simplified approach: If it's a P or H tag, we keep it. 
      // If it was a generic container, the text nodes are just preserved inline. 
      // This can cause "Art.1oArt.2o". 
      // Improved Strategy below:
      
      return hasContent ? newEl : null;
    }
    return null;
  };

  // 3. Alternative Linear Cleaning Strategy
  // Instead of complex recursion, let's iterate and clean attributes, then unwrap.
  
  const allElements = body.querySelectorAll('*');
  
  allElements.forEach(el => {
    // Strip all attributes except href for links (if we wanted links, but prompt said "plain text")
    // The prompt says: "Extraia somente o texto limpo... removendo HTML" but also "Normalizar espaços".
    // If we return pure text, we lose paragraph breaks. We will return minimal semantic HTML.
    
    while (el.attributes.length > 0) {
      el.removeAttribute(el.attributes[0].name);
    }
    
    // Convert deprecated visual tags to semantic ones or unwrap
    if (['FONT', 'CENTER', 'SPAN', 'DIV', 'TBODY', 'THEAD', 'TFOOT', 'COLGROUP', 'COL'].includes(el.tagName)) {
      // Unwrap: replace element with its children
      const parent = el.parentNode;
      while (el.firstChild) {
        parent?.insertBefore(el.firstChild, el);
      }
      parent?.removeChild(el);
    }
    
    // Handle Tables - Planalto uses tables for layout. We want to convert rows to paragraphs usually.
    // But strictly unwrapping might merge cells. 
    // Let's replace TRs with P or BR? 
    // For now, let's stick to simple unwrapping of structural tables.
    if (['TABLE', 'TR', 'TD', 'TH'].includes(el.tagName)) {
       // Often simpler to just unwrap and rely on inner Ps. 
       // If text is direct child of TD, wrap in P?
       // Let's just unwrap and let the flow handle it.
       const parent = el.parentNode;
       // Insert a space or break before content?
       while (el.firstChild) {
         parent?.insertBefore(el.firstChild, el);
       }
       // Insert a break after unwrapping a row/cell to prevent concatenation?
       const br = document.createElement('br');
       parent?.insertBefore(br, el);
       parent?.removeChild(el);
    }
  });

  // 4. Final Sanitize of content
  let cleanedHtml = body.innerHTML;

  // Normalize excessive breaks created by table unwrapping
  cleanedHtml = cleanedHtml.replace(/(<br\s*\/?>\s*){3,}/gi, '<br><br>'); 
  
  // Wrap raw text in P tags if needed, or rely on the reader css.
  // The LawReader expects HTML. We returned a stripped version.
  
  // Ensure we have a container
  const wrapper = document.createElement('div');
  wrapper.className = 'law-text-content';
  wrapper.innerHTML = cleanedHtml;

  // Post-processing: remove empty tags
  wrapper.querySelectorAll('*').forEach(el => {
    if (!el.textContent?.trim() && el.tagName !== 'BR') {
      el.remove();
    }
  });

  return wrapper.innerHTML;
};
