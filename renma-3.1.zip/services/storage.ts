
import { Law, Theory, Subject, CardStats } from '../types';
import { deleteFile } from './fileStorage';

const LAWS_KEY = 'arcadia_laws_v2';
const THEORIES_KEY = 'arcadia_theories_v1';
const SUBJECTS_KEY = 'arcadia_subjects_v1';

// --- Subjects Storage (Matérias/Pastas) ---

export const getSubjects = (): Subject[] => {
  try {
    const item = localStorage.getItem(SUBJECTS_KEY);
    return item ? JSON.parse(item) : [];
  } catch (error) {
    return [];
  }
};

export const saveSubject = (subject: Subject): void => {
  const subjects = getSubjects();
  const index = subjects.findIndex(s => s.id === subject.id);
  if (index !== -1) {
    subjects[index] = subject;
  } else {
    subjects.unshift(subject);
  }
  localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
};

export const deleteSubject = (id: string): void => {
  const subjects = getSubjects();
  localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects.filter(s => s.id !== id)));
  
  // Opcional: Deletar todos os treinos vinculados a esta matéria
  const laws = getLaws();
  const filteredLaws = laws.filter(l => l.subjectId !== id);
  localStorage.setItem(LAWS_KEY, JSON.stringify(filteredLaws));
};

export const getSubjectById = (id: string): Subject | undefined => {
  return getSubjects().find(s => s.id === id);
};

export const createEmptySubject = (): Subject => {
  return {
    id: crypto.randomUUID(),
    title: 'Nova Matéria',
    description: 'Sem descrição',
    createdAt: Date.now()
  };
};

// --- Laws Storage (Sessões de Treino) ---

const getLawsStorage = (): Law[] | null => {
  try {
    const item = localStorage.getItem(LAWS_KEY);
    return item ? JSON.parse(item) : null;
  } catch (error) {
    return null;
  }
};

const setLawsStorage = (laws: Law[]) => {
  localStorage.setItem(LAWS_KEY, JSON.stringify(laws));
};

export const createEmptyLaw = (subjectId: string): Law => {
  return {
    id: crypto.randomUUID(),
    subjectId: subjectId,
    title: 'Novo Treino',
    description: '',
    cards: [],
    content: '',
    notes: [],
    stats: {},
    createdAt: Date.now(),
  };
};

export const getLaws = (): Law[] => {
  return getLawsStorage() || [];
};

export const getLawsBySubject = (subjectId: string): Law[] => {
  return getLaws().filter(l => l.subjectId === subjectId);
};

export const getLawById = (id: string): Law | undefined => {
  return getLaws().find((l) => l.id === id);
};

export const saveLaw = (law: Law): void => {
  const laws = getLaws();
  const index = laws.findIndex((l) => l.id === law.id);
  if (index !== -1) {
    laws[index] = law;
  } else {
    laws.unshift(law);
  }
  setLawsStorage(laws);
};

export const updateLawStats = (lawId: string, cardId: string, isCorrect: boolean) => {
  const laws = getLaws();
  const lawIndex = laws.findIndex(l => l.id === lawId);
  if (lawIndex === -1) return;
  const law = laws[lawIndex];
  if (!law.stats) law.stats = {};
  const currentStats = law.stats[cardId] || {
    attempts: 0,
    correctCount: 0,
    incorrectCount: 0,
    lastResult: isCorrect ? 'correct' : 'incorrect',
    lastAnsweredAt: 0
  };
  currentStats.attempts += 1;
  currentStats.lastAnsweredAt = Date.now();
  currentStats.lastResult = isCorrect ? 'correct' : 'incorrect';
  if (isCorrect) currentStats.correctCount += 1; else currentStats.incorrectCount += 1;
  law.stats[cardId] = currentStats;
  laws[lawIndex] = law;
  setLawsStorage(laws);
};

export const toggleCardFavorite = (lawId: string, cardId: string): boolean => {
  const laws = getLaws();
  const lawIndex = laws.findIndex(l => l.id === lawId);
  if (lawIndex === -1) return false;
  const law = laws[lawIndex];
  const cardIndex = law.cards.findIndex(c => c.id === cardId);
  if (cardIndex === -1) return false;
  const newState = !law.cards[cardIndex].isFavorite;
  law.cards[cardIndex].isFavorite = newState;
  laws[lawIndex] = law;
  setLawsStorage(laws);
  return newState;
};

export const deleteLaw = (id: string): void => {
  const laws = getLaws();
  setLawsStorage(laws.filter((l) => l.id !== id));
};

// --- Theory Storage ---

export const getTheories = (): Theory[] => {
  try {
    const item = localStorage.getItem(THEORIES_KEY);
    return item ? JSON.parse(item) : [];
  } catch (error) {
    return [];
  }
};

export const getTheoryById = (id: string): Theory | undefined => {
  return getTheories().find(t => t.id === id);
};

export const saveTheory = (theory: Theory): void => {
  const list = getTheories();
  const index = list.findIndex(t => t.id === theory.id);
  const safeTheory = { ...theory };
  if (safeTheory.hasExternalPdf) safeTheory.pdfContent = undefined; 
  if (index !== -1) {
    list[index] = safeTheory;
  } else {
    list.unshift(safeTheory);
  }
  localStorage.setItem(THEORIES_KEY, JSON.stringify(list));
};

export const deleteTheory = (id: string): void => {
  const list = getTheories();
  localStorage.setItem(THEORIES_KEY, JSON.stringify(list.filter(t => t.id !== id)));
  deleteFile(id).catch(err => console.error("Error deleting file from DB:", err));
};

export const createEmptyTheory = (): Theory => {
  return {
    id: crypto.randomUUID(),
    title: 'Novo Fichamento',
    subject: '',
    htmlContent: '',
    contentType: 'pdf',
    createdAt: Date.now()
  };
};
