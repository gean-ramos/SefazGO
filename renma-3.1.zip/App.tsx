
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useParams } from 'react-router-dom';
import { SessionCreateModal } from './components/SessionCreateModal';
import { StudyCard } from './components/StudyCard';
import { Dashboard } from './components/Dashboard';
import { SubjectSessions } from './components/SubjectSessions';
import { SubjectEditor } from './components/SubjectEditor';
import { LawEditor } from './components/LawEditor';
import { TheoryEditor } from './components/TheoryEditor';
import { TheoryReader } from './components/TheoryReader';
import { ShareRoute } from './components/ShareRoute';
import { Landing } from './components/Landing';
import { SessionConfig, Card, Law, CardStats } from './types';
import { getLawById, updateLawStats, toggleCardFavorite } from './services/storage';
import { ArrowLeft, Type, List, Filter, AlertCircle, Printer, Dumbbell } from 'lucide-react';

const StudySession: React.FC = () => {
  const { lawId } = useParams<{ lawId: string }>();
  const navigate = useNavigate();
  const [law, setLaw] = useState<Law | null>(null);
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(true);
  const [sessionCards, setSessionCards] = useState<Card[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [sessionTitle, setSessionTitle] = useState('');
  const [sessionOffset, setSessionOffset] = useState(0);
  const [displayTotal, setDisplayTotal] = useState(0);

  useEffect(() => {
    if (lawId) {
      const data = getLawById(lawId);
      if (data) {
        setLaw(data);
        setSessionTitle(data.title);
      } else {
        navigate('/dashboard');
      }
    }
  }, [lawId, navigate]);

  const handleCreateSession = (config: SessionConfig) => {
    if (!law) return;
    let filtered: Card[] = [];
    let offset = 0;
    let total = 0;
    if (config.retryIncorrect && law.stats) {
      filtered = law.cards.filter(card => {
         const stat = law.stats![card.id];
         return stat && stat.lastResult === 'incorrect';
      });
      total = filtered.length;
      offset = 0;
    } else if (config.resumeProgress) {
      filtered = law.cards.filter(card => {
         const stat = law.stats ? law.stats[card.id] : undefined;
         return !stat;
      });
      total = law.cards.length;
      offset = total - filtered.length;
    } else if (config.onlyFavorites) {
        filtered = law.cards.filter(card => card.isFavorite);
        total = filtered.length;
        offset = 0;
    } else {
      filtered = law.cards.filter(card => {
        const matchesFilter = config.filters.length === 0 || config.filters.includes(card.mastery);
        const matchesArticle = config.selectedArticles.length === 0 || config.selectedArticles.includes(card.articleId);
        return matchesFilter && matchesArticle;
      });
      total = filtered.length;
      offset = 0;
    }
    if (filtered.length === 0) {
      alert("Nenhuma questão encontrada para este critério.");
      return;
    }
    setSessionCards(filtered);
    setSessionTitle(config.name);
    setCurrentCardIndex(0);
    setSessionOffset(offset);
    setDisplayTotal(total);
    setIsSessionModalOpen(false);
  };

  const handleNext = () => {
    if (currentCardIndex < sessionCards.length - 1) setCurrentCardIndex(prev => prev + 1);
  };

  const handlePrev = () => {
    if (currentCardIndex > 0) setCurrentCardIndex(prev => prev - 1);
  };

  const handleShuffle = () => {
    if (sessionCards.length <= 1) return;
    let newIndex;
    do { newIndex = Math.floor(Math.random() * sessionCards.length); } while (newIndex === currentCardIndex);
    setCurrentCardIndex(newIndex);
  };

  const handleCardResult = (isCorrect: boolean) => {
    if (law && sessionCards[currentCardIndex]) {
        const cardId = sessionCards[currentCardIndex].id;
        updateLawStats(law.id, cardId, isCorrect);
        setLaw(prev => {
            if (!prev) return null;
            const newStats = { ...(prev.stats || {}) };
            const existingStat = newStats[cardId];
            const currentStat: CardStats = existingStat ? { ...existingStat } : {
                attempts: 0, correctCount: 0, incorrectCount: 0, lastResult: isCorrect ? 'correct' : 'incorrect', lastAnsweredAt: 0
            };
            currentStat.attempts += 1;
            currentStat.lastAnsweredAt = Date.now();
            currentStat.lastResult = isCorrect ? 'correct' : 'incorrect';
            if (isCorrect) currentStat.correctCount++; else currentStat.incorrectCount++;
            newStats[cardId] = currentStat;
            return { ...prev, stats: newStats };
        });
    }
  };
  
  const handleToggleFavorite = (cardId: string) => {
      if (!law) return;
      const newStatus = toggleCardFavorite(law.id, cardId);
      setLaw(prev => {
          if (!prev) return null;
          return { ...prev, cards: prev.cards.map(c => c.id === cardId ? { ...c, isFavorite: newStatus } : c) };
      });
      setSessionCards(prev => prev.map(c => c.id === cardId ? { ...c, isFavorite: newStatus } : c));
  };

  if (!law) return null;

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-800 font-sans">
      <header className="sticky top-0 z-40 bg-black text-white shadow-md">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
             <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-neutral-400 hover:bg-neutral-800 rounded-full transition-colors">
               <ArrowLeft size={20} />
             </button>
             <h1 className="font-bold text-lg truncate">{law.title}</h1>
          </div>
          <div className="flex items-center gap-2 text-neutral-400">
             <button onClick={() => setIsSessionModalOpen(true)} className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-neutral-800 hover:text-white border border-neutral-700 transition-colors">
                <Filter size={18} />
             </button>
          </div>
        </div>
      </header>

      {!isSessionModalOpen && sessionCards.length > 0 && (
        <div className="bg-black border-t border-neutral-800 px-4 py-3 shadow-lg relative z-30">
          <div className="max-w-4xl mx-auto flex justify-center text-center">
             <span className="text-sm font-medium text-white truncate max-w-full italic">
                {law.description || sessionTitle}
             </span>
          </div>
        </div>
      )}

      <main className="max-w-4xl mx-auto">
        {!isSessionModalOpen && sessionCards.length > 0 ? (
          <StudyCard card={sessionCards[currentCardIndex]} total={displayTotal} current={currentCardIndex + 1 + sessionOffset} onNext={handleNext} onPrev={handlePrev} onShuffle={handleShuffle} onResult={handleCardResult} onToggleFavorite={handleToggleFavorite} />
        ) : (
           !isSessionModalOpen && (
             <div className="flex flex-col items-center justify-center min-h-[50vh] text-neutral-400 px-4 text-center">
               <Dumbbell size={64} className="mb-6 opacity-20" />
               <p className="font-medium text-lg mb-2">Treino não iniciado</p>
               <button onClick={() => setIsSessionModalOpen(true)} className="mt-6 px-8 py-3 bg-red-700 text-white rounded-xl font-bold shadow-lg hover:bg-red-800 transition-all">Configurar Treino</button>
             </div>
           )
        )}
      </main>

      {isSessionModalOpen && (
        <SessionCreateModal onClose={() => sessionCards.length > 0 ? setIsSessionModalOpen(false) : navigate(-1)} onCreate={handleCreateSession} availableCards={law.cards} defaultName={law.title} lawStats={law.stats} />
      )}
    </div>
  );
};

const App = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/subject/:subjectId" element={<SubjectSessions />} />
        <Route path="/subject/edit/:id" element={<SubjectEditor />} />
        <Route path="/edit/:id" element={<LawEditor />} />
        <Route path="/study/:lawId" element={<StudySession />} />
        <Route path="/theory/edit/:id" element={<TheoryEditor />} />
        <Route path="/theory/view/:id" element={<TheoryReader />} />
        <Route path="/share" element={<ShareRoute />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
