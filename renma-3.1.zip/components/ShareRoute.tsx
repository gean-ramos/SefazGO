import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { parseShareLink } from '../utils/shareUtils';
import { Law } from '../types';
import { saveLaw, getLaws } from '../services/storage';
import { Download, AlertTriangle, CheckCircle, FileText, List, ArrowRight } from 'lucide-react';

export const ShareRoute: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [importedLaw, setImportedLaw] = useState<Law | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const law = parseShareLink(searchParams);
    if (law) {
      setImportedLaw(law);
    } else {
      setError("Link inválido ou corrompido.");
    }
  }, [searchParams]);

  const handleConfirmImport = () => {
    if (importedLaw) {
      // Check for duplicates based on Title to prevent confusion
      const existing = getLaws().find(l => l.title === importedLaw.title);
      
      if (existing) {
         if (!window.confirm(`Você já possui um treino chamado "${importedLaw.title}" na sua biblioteca. Importar novamente criará uma cópia duplicada. Deseja continuar?`)) {
             navigate('/dashboard');
             return;
         }
      }

      saveLaw(importedLaw);
      navigate('/');
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4">
        <div className="bg-white p-6 rounded-2xl shadow-xl max-w-md w-full text-center">
          <div className="w-16 h-16 bg-rose-100 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle size={32} />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Erro ao Importar</h2>
          <p className="text-slate-500 mb-6">{error}</p>
          <button 
            onClick={() => navigate('/')}
            className="w-full py-3 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200"
          >
            Voltar ao Início
          </button>
        </div>
      </div>
    );
  }

  if (!importedLaw) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 bg-slate-200 rounded-full mb-4"></div>
          <div className="h-4 w-48 bg-slate-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-lg w-full border border-slate-100">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-50 rotate-3">
            <Download size={40} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">Legislação Compartilhada</h1>
          <p className="text-slate-500">Você recebeu um novo pacote de estudos.</p>
        </div>

        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 mb-8">
          <h3 className="font-bold text-lg text-slate-800 mb-1">{importedLaw.title}</h3>
          <p className="text-sm text-slate-500 mb-4">{importedLaw.description || 'Sem descrição'}</p>
          
          <div className="flex gap-4 border-t border-slate-200 pt-4">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-600">
              <List size={16} className="text-emerald-500" />
              {importedLaw.cards.length} Questões
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-slate-600">
              <FileText size={16} className="text-blue-500" />
              {importedLaw.notes.length} Notas
            </div>
          </div>
          
          {!importedLaw.htmlContent && importedLaw.sourceUrl && (
             <div className="mt-4 text-xs bg-yellow-50 text-yellow-700 p-2 rounded border border-yellow-100 flex gap-2 items-start">
               <AlertTriangle size={14} className="mt-0.5 shrink-0" />
               <p>O texto da lei precisa ser baixado novamente. Use o botão "Buscar Lei" após importar.</p>
             </div>
          )}
        </div>

        <div className="flex flex-col gap-3">
          <button 
            onClick={handleConfirmImport}
            className="w-full py-4 bg-emerald-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-200 hover:bg-emerald-600 hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
          >
            <CheckCircle size={20} />
            Importar para Minha Biblioteca
          </button>
          <button 
            onClick={() => navigate('/')}
            className="w-full py-3 text-slate-400 font-bold hover:text-slate-600 text-sm"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};