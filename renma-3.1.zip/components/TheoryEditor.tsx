import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, CheckCircle, Eye, FileText, RefreshCw, AlertCircle, Trash2 } from 'lucide-react';
import { Theory } from '../types';
import { getTheoryById, saveTheory } from '../services/storage';
import { saveFile } from '../services/fileStorage';

// Declaration for the Mammoth library added in index.html
declare const mammoth: any;

export const TheoryEditor: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [theory, setTheory] = useState<Theory | null>(null);
  
  // States to match the provided snippet logic
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  
  // Preview State
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileType, setFileType] = useState<'pdf' | 'docx' | null>(null);
  const [fileName, setFileName] = useState<string>('');

  // Replacement State
  const [isReplacing, setIsReplacing] = useState(false);

  useEffect(() => {
    if (id) {
      const data = getTheoryById(id);
      if (data) {
        setTheory(data);
        // Determine file type based on stored data
        if (data.contentType === 'pdf') {
             setFileType('pdf');
        } else if (data.contentType === 'html' || data.contentType === 'docx') {
             setFileType('docx');
        }
      } else {
        navigate('/');
      }
    }
  }, [id, navigate]);

  const handleUpdate = (field: keyof Theory, value: any) => {
    if (theory) {
      setTheory({ ...theory, [field]: value });
    }
  };

  const handleSave = () => {
    if (theory) {
      saveTheory(theory);
      navigate(`/theory/view/${theory.id}`);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !theory) return;

    // Reset UI
    setPreviewUrl(null);
    setFileType(null);
    setStatusMsg("");
    setUploadProgress(0);

    const extension = file.name.split(".").pop()?.toLowerCase();

    if (extension !== "pdf" && extension !== "docx") {
      setStatusMsg("Formato não suportado. Use arquivos .pdf ou .docx.");
      return;
    }

    setFileName(file.name);
    setFileType(extension as 'pdf' | 'docx');

    // Auto-fill title if empty or default
    if (!theory.title || theory.title === 'Novo Fichamento') {
       handleUpdate('title', file.name.replace(/\.(pdf|docx)$/i, ''));
    }

    // Prepare Upload
    setIsUploading(true);
    setStatusMsg("Processando arquivo...");

    const reader = new FileReader();

    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 100);
        setUploadProgress(percent);
      }
    };

    reader.onload = async () => {
        try {
            const arrayBuffer = reader.result as ArrayBuffer;

            // WORD PROCESSING (.docx)
            if (extension === 'docx') {
                setStatusMsg("Convertendo Word para HTML...");
                try {
                  const result = await mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
                  const html = result.value; // The generated HTML
                  const messages = result.messages; // Any warnings
                  
                  // Update Theory with HTML Content
                  setTheory(prev => prev ? { 
                      ...prev, 
                      contentType: 'html', 
                      htmlContent: html,
                      hasExternalPdf: true,
                      pdfContent: undefined // Clear legacy PDF content if switching types
                  } : null);

                  setStatusMsg("Conversão de Word concluída com sucesso.");
                } catch (err) {
                  console.error("Mammoth error", err);
                  setStatusMsg("Erro ao converter arquivo Word. O arquivo original será salvo.");
                }
            } 
            // PDF PROCESSING
            else if (extension === 'pdf') {
                 const blob = new Blob([arrayBuffer], { type: 'application/pdf' });
                 const localUrl = URL.createObjectURL(blob);
                 setPreviewUrl(localUrl);
                 
                 setTheory(prev => prev ? { 
                    ...prev, 
                    contentType: 'pdf',
                    hasExternalPdf: true,
                    pdfContent: undefined,
                    htmlContent: undefined // Clear HTML content if switching to PDF
                 } : null);
            }

            // Save the raw file to IndexedDB (Overwrites existing file for this ID)
            let mimeType = file.type;
            if (extension === 'pdf') mimeType = 'application/pdf';
            else if (extension === 'docx') mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            
            const blob = new Blob([arrayBuffer], { type: mimeType });
            await saveFile(theory.id, blob);
            
            setUploadProgress(100);
            if (extension === 'pdf') setStatusMsg("PDF salvo com sucesso.");
            setIsReplacing(false); // Exit replacement mode on success
            
        } catch (error) {
            console.error(error);
            setStatusMsg("Erro ao salvar arquivo.");
        } finally {
            setIsUploading(false);
        }
    };

    reader.onerror = () => {
      setStatusMsg("Erro ao ler o arquivo.");
      setIsUploading(false);
    };

    reader.readAsArrayBuffer(file);
  };

  if (!theory) return null;

  // Determine if there is an existing file loaded
  const hasExistingFile = theory.hasExternalPdf || (theory.contentType === 'html' && !!theory.htmlContent);

  return (
    <>
      <style>{`
        body { margin: 0; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f5f5f5; }
        .page { padding: 16px; }
        .card { background: #ffffff; border-radius: 8px; padding: 16px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08); max-width: 900px; margin: 0 auto; }
        .field-group { margin-bottom: 16px; }
        .field-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 4px; color: #333333; }
        .field-group input[type="text"] { width: 100%; padding: 8px 10px; border-radius: 4px; border: 1px solid #cccccc; font-size: 14px; box-sizing: border-box; }
        .upload-area { border: 1px dashed #c62828; background: #fff7f7; border-radius: 8px; padding: 16px; text-align: center; }
        .upload-area input[type="file"] { margin-top: 8px; }
        .progress-wrapper { margin-top: 12px; }
        .progress-bar-bg { width: 100%; height: 8px; border-radius: 4px; background: #eeeeee; overflow: hidden; }
        .progress-bar-fill { height: 100%; width: 0%; background: #c62828; transition: width 0.15s linear; }
        .progress-text { font-size: 11px; margin-top: 4px; text-align: right; color: #555555; }
        .status-text { margin-top: 8px; font-size: 12px; color: #555555; text-align: left; }
        .preview-container { margin-top: 24px; }
        .preview-title { font-size: 14px; font-weight: 600; margin-bottom: 8px; }
        #previewWord { padding: 8px; background: #fafafa; border-radius: 4px; border: 1px solid #dddddd; font-size: 13px; }
        #previewPdf { width: 100%; height: 520px; border: 1px solid #dddddd; border-radius: 4px; background: #e0e0e0; }
        
        .existing-file-card {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
      `}</style>

      {/* Standard App Header to keep navigation working */}
      <div className="bg-black text-white sticky top-0 z-20 shadow-md">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/dashboard')} className="p-2 -ml-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-full transition-colors">
              <ArrowLeft size={20} />
            </button>
            <h1 className="font-bold text-lg">Editor de Fichamento</h1>
          </div>
          <button 
            onClick={handleSave}
            disabled={isUploading}
            className="flex items-center gap-2 px-4 py-2 bg-red-700 text-white rounded-lg font-bold text-sm hover:bg-red-600 transition-colors disabled:opacity-50 shadow-lg shadow-red-900/30"
          >
            <Eye size={16} /> Salvar e Visualizar
          </button>
        </div>
      </div>

      <div className="page">
        <div className="card">
          {/* Cabeçalho do fichamento */}
          <div className="field-group">
            <label htmlFor="titulo">Título do material</label>
            <input 
              id="titulo" 
              type="text" 
              placeholder="Novo Fichamento" 
              value={theory.title}
              onChange={(e) => handleUpdate('title', e.target.value)}
            />
          </div>

          <div className="field-group">
            <label htmlFor="materia">Matéria / Assunto</label>
            <input 
              id="materia" 
              type="text" 
              placeholder="Ex: Contabilidade" 
              value={theory.subject}
              onChange={(e) => handleUpdate('subject', e.target.value)}
            />
          </div>

          {/* Upload / Replacement Logic */}
          <div className="field-group">
            <label>Conteúdo Principal</label>
            
            {hasExistingFile && !isReplacing ? (
                <div className="existing-file-card">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
                            <FileText size={20} />
                        </div>
                        <div>
                            <p className="font-bold text-sm text-slate-800">
                                {fileType === 'pdf' ? 'Documento PDF' : 'Documento Word / Texto'}
                            </p>
                            <p className="text-xs text-slate-500">
                                {theory.hasExternalPdf ? 'Arquivo original salvo.' : 'Conteúdo extraído.'}
                            </p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setIsReplacing(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50 hover:text-red-600 transition-colors"
                    >
                        <RefreshCw size={14} /> Substituir Arquivo
                    </button>
                </div>
            ) : (
                <div className="upload-area animate-in fade-in">
                    {isReplacing && (
                        <div className="flex justify-end mb-2">
                             <button onClick={() => setIsReplacing(false)} className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1">
                                <Trash2 size={12} /> Cancelar substituição
                             </button>
                        </div>
                    )}
                    
                    <div className="mb-2 font-medium text-neutral-600">Selecione um arquivo .docx ou .pdf</div>
                    <input
                        id="fileInput"
                        type="file"
                        className="block w-full text-sm text-slate-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-full file:border-0
                        file:text-sm file:font-semibold
                        file:bg-red-50 file:text-red-700
                        hover:file:bg-red-100 cursor-pointer
                        "
                        accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        onChange={handleFileChange}
                        disabled={isUploading}
                    />

                    <div id="progressWrapper" className="progress-wrapper" style={{ display: (isUploading || uploadProgress > 0) ? 'block' : 'none' }}>
                        <div className="progress-bar-bg">
                        <div id="progressBar" className="progress-bar-fill" style={{ width: `${uploadProgress}%` }}></div>
                        </div>
                        <div id="progressText" className="progress-text">{uploadProgress}%</div>
                    </div>

                    <div id="statusMsg" className="status-text font-bold text-red-700">{statusMsg}</div>
                </div>
            )}
          </div>

          {/* Pré-visualização */}
          {(previewUrl || fileType === 'docx' || theory.htmlContent) && !isReplacing && (
            <div className="preview-container">
              <div className="preview-title">Pré-visualização do Conteúdo</div>

              {fileType === 'docx' || (theory.contentType === 'html' && theory.htmlContent) ? (
                <div className="border border-neutral-200 rounded-lg p-6 bg-white shadow-inner max-h-[500px] overflow-y-auto">
                    <p className="text-sm font-bold text-green-700 mb-4 flex items-center gap-2">
                        <CheckCircle size={16} /> Conteúdo extraído com sucesso.
                    </p>
                    <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: theory.htmlContent || '' }} />
                </div>
              ) : (
                <div id="previewPdfContainer">
                  <iframe 
                    id="previewPdf" 
                    src={previewUrl || ""} 
                    title="Pré-visualização PDF"
                    style={{ display: 'block' }}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};