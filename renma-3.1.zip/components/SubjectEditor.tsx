
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Loader2, Check, Edit3 } from 'lucide-react';
import { Subject } from '../types';
import { getSubjectById, saveSubject } from '../services/storage';

export const SubjectEditor: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  useEffect(() => {
    if (id) {
      const data = getSubjectById(id);
      if (data) {
        setSubject(data);
      } else {
        navigate('/dashboard');
      }
    }
  }, [id, navigate]);

  const handleSave = () => {
    if (subject) {
      setSaveStatus('saving');
      saveSubject(subject);
      setSaveStatus('saved');
      setTimeout(() => {
        navigate('/dashboard');
      }, 800);
    }
  };

  if (!subject) return <div className="min-h-screen bg-neutral-100 flex items-center justify-center"><Loader2 className="animate-spin text-red-700" /></div>;

  return (
    <div className="min-h-screen bg-neutral-100 font-sans">
      {/* Header Minimalista (Apenas Controles) */}
      <div className="bg-black text-white sticky top-0 z-30 shadow-lg h-20">
        <div className="max-w-2xl mx-auto px-6 h-full flex items-center justify-between">
          <button 
            onClick={() => navigate('/dashboard')} 
            className="p-3 -ml-3 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-2xl transition-all active:scale-90"
          >
            <ArrowLeft size={24} />
          </button>
          
          <button 
            onClick={handleSave}
            disabled={saveStatus !== 'idle'}
            className={`group flex items-center gap-3 px-6 py-2.5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all shadow-xl active:scale-95 ${
              saveStatus === 'saved' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-white text-black hover:bg-neutral-100'
            }`}
          >
            <div className={`p-1 rounded-md transition-colors ${saveStatus === 'saved' ? 'bg-emerald-500' : 'bg-neutral-100 group-hover:bg-neutral-200'}`}>
              {saveStatus === 'saving' ? <Loader2 size={16} className="animate-spin" /> : 
               saveStatus === 'saved' ? <Check size={16} /> : <Save size={16} />}
            </div>
            <span>{saveStatus === 'saved' ? 'Salvo!' : 'Salvar'}</span>
          </button>
        </div>
      </div>

      <main className="max-w-2xl mx-auto px-6 py-12">
        <div className="bg-white rounded-[2.5rem] p-10 shadow-[0_20px_50px_rgba(0,0,0,0.04)] border border-neutral-200 relative overflow-hidden">
          
          {/* Ícone de Edição no Canto Superior Direito (Inspirado no Print 12) */}
          <div className="absolute top-8 right-8 text-neutral-200">
            <Edit3 size={28} strokeWidth={2.5} />
          </div>

          <div className="space-y-12 relative z-10">
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 pl-1">Nome da Matéria</label>
                <input 
                  type="text"
                  value={subject.title}
                  onChange={(e) => setSubject({ ...subject, title: e.target.value })}
                  className="w-full text-4xl font-black tracking-tighter p-6 bg-neutral-50 border-2 border-neutral-50 rounded-[2rem] focus:border-red-600 focus:bg-white focus:shadow-2xl focus:shadow-red-900/5 outline-none transition-all placeholder-neutral-200"
                  placeholder="Ex: Direito Civil"
                  autoFocus
                />
              </div>
            </div>
            
            <div className="pt-8 border-t border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></div>
                <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">Modificações salvas localmente</span>
              </div>
              <div className="text-[10px] font-black text-neutral-300 uppercase tracking-widest">
                v2.0
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
