import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export const Landing: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center relative font-sans">
      
      {/* Container Central */}
      <div className="flex flex-col items-center w-full max-w-md px-6 -mt-8">
        
        {/* Logo Container - Squircle */}
        <div className="w-[280px] h-[280px] bg-[#222222] rounded-[3.5rem] flex flex-col items-center justify-center shadow-2xl shadow-neutral-400/20 mb-10 select-none overflow-hidden relative">
            
            {/* Texto RENMA 
                - Mantendo o tamanho aumentado (+5%) e esticado (+8%)
                - Mantendo a espessura simulada (+3%)
                - Ajuste de margem superior para equilibrar o espaçamento
            */}
            <h1 
              className="text-white font-bold text-[3.36rem] tracking-[0.1em] leading-none z-10 font-inter mt-2"
              style={{
                transform: 'scaleY(1.08)',
                WebkitTextStroke: '1.5px white' 
              }}
            >
              RENMA
            </h1>
            
            {/* Texto Japonês 
                - Tamanho original ajustado (5rem)
                - Deslocado 3% para a esquerda (translateX(-3%))
                - Margem aumentada (mt-6) para criar a distância de 5% solicitada
            */}
            <span 
              className="text-[#b91c1c] font-black text-[5rem] leading-none mt-6 tracking-tighter" 
              style={{ 
                fontFamily: '"Noto Sans JP", sans-serif',
                transform: 'scaleY(1.08) translateY(-4px) translateX(-3%)',
                WebkitTextStroke: '2.5px #b91c1c'
              }}
            >
              レンマ
            </span>
        </div>

        {/* Subtítulo Harmonizado */}
        <p className="text-neutral-400 font-bold text-xs tracking-[0.2em] uppercase mb-12 text-center mt-2">
          Sistema de Repetição Inteligente
        </p>

        {/* Botão */}
        <button 
          onClick={() => navigate('/dashboard')}
          className="w-[300px] h-[60px] bg-white border-[2.5px] border-black rounded-full flex items-center justify-center gap-3 text-black font-bold text-lg hover:bg-neutral-50 transition-transform active:scale-[0.98] shadow-sm"
        >
          <span>Acessar Plataforma</span>
          <ArrowRight size={22} strokeWidth={2.5} />
        </button>

      </div>
      
      {/* Rodapé */}
      <div className="absolute bottom-10 text-neutral-200 text-[11px] font-bold tracking-[0.2em] uppercase select-none">
        RENMA v2.0
      </div>

    </div>
  );
};