import React, { useState, useEffect } from 'react';
import { Dumbbell, CheckSquare, Square, X, Target, Thermometer, Flame, Brain, BookOpen, Layers, Activity, AlertCircle, CheckCircle2, BarChart3, RotateCw, Play, Star } from 'lucide-react';
import { MasteryLevel, SessionConfig, Card, CardStats } from '../types';

interface Props {
  onClose: () => void;
  onCreate: (config: SessionConfig) => void;
  availableCards: Card[];
  defaultName: string;
  lawStats?: Record<string, CardStats>;
}

export const SessionCreateModal: React.FC<Props> = ({ onClose, onCreate, availableCards, defaultName, lawStats }) => {
  const [name, setName] = useState(defaultName);
  const [selectedFilters, setSelectedFilters] = useState<MasteryLevel[]>([MasteryLevel.EASY, MasteryLevel.MEDIUM]);
  
  // Stats Calculation
  const totalCards = availableCards.length;
  const resolvedCards = lawStats ? Object.keys(lawStats).length : 0;
  
  // Calculate unique cards correct and incorrect based on their LAST result
  const incorrectCardsCount = lawStats 
    ? Object.values(lawStats).filter((s: CardStats) => s.lastResult === 'incorrect').length 
    : 0;
    
  const correctCardsCount = lawStats
    ? Object.values(lawStats).filter((s: CardStats) => s.lastResult === 'correct').length
    : 0;
    
  const favoriteCardsCount = availableCards.filter(c => c.isFavorite).length;

  const remainingCards = totalCards - resolvedCards;
  const progressPercentage = totalCards > 0 ? Math.round((resolvedCards / totalCards) * 100) : 0;
  
  // Explicitly calculate percentages based ONLY on the answered count (correct + incorrect)
  const totalAnswered = correctCardsCount + incorrectCardsCount;
  const correctPercentage = totalAnswered > 0 ? Math.round((correctCardsCount / totalAnswered) * 100) : 0;
  const incorrectPercentage = totalAnswered > 0 ? Math.round((incorrectCardsCount / totalAnswered) * 100) : 0;

  const toggleFilter = (filter: MasteryLevel) => {
    setSelectedFilters(prev => 
      prev.includes(filter) ? prev.filter(f => f !== filter) : [...prev, filter]
    );
  };

  const handleCreate = () => {
    onCreate({
      name: name || 'Treino Personalizado',
      filters: selectedFilters,
      selectedArticles: [], // Deprecated in UI but kept for type compatibility
      retryIncorrect: false
    });
  };

  const handleRetryErrors = () => {
    onCreate({
      name: `Revisão de Erros - ${name}`,
      filters: [],
      selectedArticles: [],
      retryIncorrect: true
    });
  };

  const handleContinue = () => {
    onCreate({
        name: `Continuando - ${name}`,
        filters: [], // Ignore difficulty filters for continue mode
        selectedArticles: [],
        retryIncorrect: false,
        resumeProgress: true
    });
  };
  
  const handleFavoritesSession = () => {
    onCreate({
      name: `Favoritos - ${name}`,
      filters: [],
      selectedArticles: [],
      retryIncorrect: false,
      onlyFavorites: true
    });
  };

  // Styles for each difficulty level
  const getLevelStyle = (level: MasteryLevel) => {
    switch (level) {
      case MasteryLevel.EASY: return 'text-neutral-500 border-neutral-300 bg-neutral-50';
      case MasteryLevel.LITERAL: return 'text-blue-600 border-blue-200 bg-blue-50';
      case MasteryLevel.MEDIUM: return 'text-yellow-600 border-yellow-200 bg-yellow-50';
      case MasteryLevel.HARD: return 'text-orange-600 border-orange-200 bg-orange-50';
      case MasteryLevel.ADVANCED: return 'text-red-700 border-red-200 bg-red-50';
      default: return 'text-neutral-500';
    }
  };

  const getLevelIcon = (level: MasteryLevel) => {
    switch (level) {
      case MasteryLevel.EASY: return <BookOpen size={16} />;
      case MasteryLevel.LITERAL: return <Target size={16} />;
      case MasteryLevel.MEDIUM: return <Layers size={16} />;
      case MasteryLevel.HARD: return <Thermometer size={16} />;
      case MasteryLevel.ADVANCED: return <Flame size={16} />;
      default: return <Brain size={16} />;
    }
  };

  const FilterBadge = ({ level }: { level: MasteryLevel }) => {
    const isSelected = selectedFilters.includes(level);
    const baseStyle = getLevelStyle(level);
    
    return (
      <button 
        onClick={() => toggleFilter(level)}
        className={`flex items-center gap-2 px-3 py-3 rounded-xl text-sm font-bold transition-all border-2 w-full justify-between ${
          isSelected 
          ? `${baseStyle} ring-1 ring-offset-1 ring-neutral-200 shadow-sm` 
          : 'bg-white border-neutral-100 text-neutral-400 grayscale opacity-70 hover:opacity-100 hover:bg-neutral-50'
        }`}
      >
        <div className="flex items-center gap-2">
           {getLevelIcon(level)}
           {level}
        </div>
        {isSelected ? <CheckSquare size={16} className="text-current" /> : <Square size={16} />}
      </button>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200 font-sans">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 flex justify-between items-center bg-white">
          <div className="flex items-center gap-3 text-neutral-900">
            <div className="bg-red-700 p-1.5 rounded-lg text-white">
              <Dumbbell size={20} />
            </div>
            <h2 className="font-bold text-xl">Configurar Treino</h2>
          </div>
          <button onClick={onClose} className="p-2 bg-neutral-100 rounded-full text-neutral-400 hover:text-neutral-900 hover:bg-neutral-200 transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-6">
          
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-500">Nome da Sessão</label>
            <input 
              type="text" 
              placeholder="Nome do Treino"
              className="w-full p-4 rounded-xl bg-neutral-50 border border-neutral-200 focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none transition-all text-neutral-800 font-bold text-lg placeholder-neutral-400"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Progress Panel */}
          <div className="space-y-2">
             <div className="flex items-center gap-2 text-neutral-500 mb-1">
                <Activity size={14} />
                <label className="text-xs font-bold uppercase tracking-wider">Progresso do Bloco</label>
             </div>
             
             <div className="grid grid-cols-2 gap-3">
                {/* Total */}
                <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-100 flex flex-col items-center justify-center">
                    <span className="text-2xl font-black text-neutral-800">{totalCards}</span>
                    <span className="text-[10px] font-bold uppercase text-neutral-400">Total Questões</span>
                </div>
                
                {/* Resolved */}
                <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-100 flex flex-col items-center justify-center relative overflow-hidden">
                    <div className="absolute bottom-0 left-0 h-1 bg-neutral-200 w-full">
                       <div className="h-full bg-blue-500" style={{ width: `${progressPercentage}%` }}></div>
                    </div>
                    <span className="text-2xl font-black text-blue-600">{resolvedCards}</span>
                    <span className="text-[10px] font-bold uppercase text-blue-400">Resolvidas</span>
                </div>

                {/* Correct */}
                <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-100 flex flex-col items-center justify-center">
                    <div className="flex items-center gap-1 text-emerald-600 mb-1">
                        <CheckCircle2 size={16} />
                    </div>
                    <div className="flex items-baseline gap-1">
                        <span className="text-xl font-black text-emerald-700">{correctCardsCount}</span>
                        {totalAnswered > 0 && (
                            <span className="text-xs font-bold text-emerald-600/70">({correctPercentage}%)</span>
                        )}
                    </div>
                    <span className="text-[10px] font-bold uppercase text-emerald-400">Acertos</span>
                </div>

                {/* Incorrect (Actionable) */}
                <div className="bg-red-50 p-3 rounded-xl border border-red-100 flex flex-col items-center justify-center">
                    <div className="flex items-center gap-1 text-red-600 mb-1">
                        <AlertCircle size={16} />
                    </div>
                    <div className="flex items-baseline gap-1">
                        <span className="text-xl font-black text-red-700">{incorrectCardsCount}</span>
                        {totalAnswered > 0 && (
                            <span className="text-xs font-bold text-red-600/70">({incorrectPercentage}%)</span>
                        )}
                    </div>
                    <span className="text-[10px] font-bold uppercase text-red-400">Erros (Pendentes)</span>
                </div>
             </div>

             {/* Progress Bar (Light Tone Buffering Style) */}
             <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100 mt-2">
                 <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Progresso Geral</span>
                    <span className="text-sm font-bold text-neutral-700">{progressPercentage}%</span>
                 </div>
                 
                 <div className="h-3 w-full bg-neutral-200 rounded-full overflow-hidden relative border border-neutral-200/50">
                    <div 
                        className="h-full bg-neutral-400 transition-all duration-500 ease-out relative"
                        style={{ width: `${progressPercentage > 0 ? progressPercentage : 0}%` }}
                    >
                         {/* Buffering/Striped Effect */}
                         <div 
                            className="absolute inset-0 w-full h-full opacity-40" 
                            style={{ 
                                backgroundImage: 'linear-gradient(45deg,rgba(255,255,255,.4) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.4) 50%,rgba(255,255,255,.4) 75%,transparent 75%,transparent)', 
                                backgroundSize: '1rem 1rem' 
                            }}
                         ></div>
                    </div>
                 </div>
                 
                 <div className="text-right mt-1.5">
                     <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wide">Faltam {remainingCards} questões</span>
                 </div>
             </div>
          </div>

          {/* Difficulty Filters */}
          <div className="space-y-4 pt-2 border-t border-neutral-100">
            <div className="flex items-center gap-2 text-neutral-800 pb-2">
              <Target size={18} className="text-red-600" />
              <span className="font-bold text-sm">Filtrar por Dificuldade</span>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <FilterBadge level={MasteryLevel.EASY} />
              <FilterBadge level={MasteryLevel.LITERAL} />
              <FilterBadge level={MasteryLevel.MEDIUM} />
              <FilterBadge level={MasteryLevel.HARD} />
              <div className="col-span-2">
                <FilterBadge level={MasteryLevel.ADVANCED} />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-neutral-100 bg-white space-y-3">
          
          <div className="flex gap-2">
              {incorrectCardsCount > 0 && (
                <button 
                    onClick={handleRetryErrors}
                    className="flex-1 py-3 bg-red-100 text-red-800 font-bold rounded-xl hover:bg-red-200 transition-colors flex items-center justify-center gap-2 border border-red-200 text-xs"
                >
                    <RotateCw size={16} />
                    Refazer Erros
                </button>
              )}
              
              {favoriteCardsCount > 0 && (
                <button 
                    onClick={handleFavoritesSession}
                    className="flex-1 py-3 bg-yellow-100 text-yellow-800 font-bold rounded-xl hover:bg-yellow-200 transition-colors flex items-center justify-center gap-2 border border-yellow-200 text-xs"
                >
                    <Star size={16} fill="currentColor" />
                    Revisar Favoritos ({favoriteCardsCount})
                </button>
              )}
          </div>

          {resolvedCards > 0 && remainingCards > 0 && (
              <button 
                 onClick={handleContinue}
                 className="w-full py-3 bg-blue-100 text-blue-800 font-bold rounded-xl hover:bg-blue-200 transition-colors flex items-center justify-center gap-2 mb-2 border border-blue-200"
              >
                 <Play size={18} fill="currentColor" />
                 Continuar de onde parei ({remainingCards})
              </button>
          )}

          <button 
            onClick={handleCreate}
            disabled={availableCards.length === 0}
            className="w-full py-4 bg-neutral-900 text-white font-bold rounded-xl shadow-lg shadow-neutral-500/20 hover:bg-red-700 hover:shadow-red-900/20 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Dumbbell size={18} />
            Iniciar Treino
          </button>
          <button 
            onClick={onClose}
            className="w-full py-3 text-neutral-400 font-bold text-sm hover:text-neutral-800 transition-colors"
          >
            Cancelar
          </button>
        </div>

      </div>
    </div>
  );
};