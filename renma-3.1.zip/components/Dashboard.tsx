
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Dumbbell, Edit3, Trash2, Search, Zap, Scale, BookOpen, FileText, ArrowRight, ArrowLeft } from 'lucide-react';
import { Subject, Theory } from '../types';
import { getSubjects, createEmptySubject, saveSubject, deleteSubject, getTheories, deleteTheory, createEmptyTheory, saveTheory, getLawsBySubject } from '../services/storage';

export const Dashboard: React.FC = () => {
  const [mode, setMode] = useState<'theory' | 'training'>(() => {
    return (localStorage.getItem('arcadia_dashboard_mode') as 'theory' | 'training') || 'theory';
  });
  
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [theories, setTheories] = useState<Theory[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    refreshData();
  }, [mode]);

  useEffect(() => {
    localStorage.setItem('arcadia_dashboard_mode', mode);
  }, [mode]);

  const refreshData = () => {
    if (mode === 'training') {
      setSubjects(getSubjects());
    } else {
      setTheories(getTheories());
    }
  };

  const handleCreate = () => {
    if (mode === 'training') {
      const newSubject = createEmptySubject();
      saveSubject(newSubject);
      setSubjects(prev => [newSubject, ...prev]);
      // Navega para o editor imediatamente após criar para permitir nomear a matéria
      navigate(`/subject/edit/${newSubject.id}`);
    } else {
      const newTheory = createEmptyTheory();
      saveTheory(newTheory);
      navigate(`/theory/edit/${newTheory.id}`);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (window.confirm('Tem certeza que deseja excluir este item?')) {
      if (mode === 'training') {
          deleteSubject(id);
          setSubjects(prev => prev.filter(s => s.id !== id));
      } else {
          deleteTheory(id);
          setTheories(prev => prev.filter(t => t.id !== id));
      }
    }
  };

  const handleEditSubject = (subject: Subject, e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/subject/edit/${subject.id}`);
  };

  const filteredSubjects = subjects.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTheories = theories.filter(t => 
    t.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    t.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-neutral-100 pb-20 font-sans">
      {/* Header Otimizado */}
      <div className="bg-black text-white sticky top-0 z-30 shadow-lg shadow-black/10">
        <div className="max-w-4xl mx-auto px-6 pt-4 pb-2">
          <button 
             onClick={() => navigate('/')}
             className="flex items-center gap-2 text-neutral-400 hover:text-white mb-3 text-xs font-bold uppercase tracking-wider transition-colors"
          >
             <ArrowLeft size={14} /> Voltar ao Início
          </button>
          
          {/* Seletor de Abas Estilo Moderno - Largura Total (Edge-to-Edge) */}
          <div className="flex justify-center mb-6">
            <div className="bg-neutral-900 w-full max-w-[320px] h-14 rounded-2xl flex border border-neutral-800 shadow-inner overflow-hidden">
              <button 
                onClick={() => setMode('theory')}
                className={`flex-1 flex items-center justify-center transition-all duration-300 relative ${
                  mode === 'theory' 
                    ? 'bg-neutral-800 text-blue-400' 
                    : 'text-neutral-600 hover:text-neutral-400'
                }`}
                title="Fichamento Teórico"
              >
                <BookOpen size={28} strokeWidth={mode === 'theory' ? 2.5 : 2} />
                {mode === 'theory' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500/50"></div>}
              </button>
              <button 
                onClick={() => setMode('training')}
                className={`flex-1 flex items-center justify-center transition-all duration-300 relative ${
                  mode === 'training' 
                    ? 'bg-red-700 text-white shadow-[inset_0_0_20px_rgba(0,0,0,0.2)]' 
                    : 'text-neutral-600 hover:text-neutral-400'
                }`}
                title="Sessões de Treino"
              >
                <Dumbbell size={28} strokeWidth={mode === 'training' ? 2.5 : 2} />
                {mode === 'training' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20"></div>}
              </button>
            </div>
          </div>

          {/* Seção de Título e Ação - Harmonização Premium */}
          <div className="flex items-center justify-between mb-8 gap-4 px-1 min-h-[64px]">
            <h1 className="font-black tracking-tight leading-none whitespace-nowrap transition-all duration-500 select-none">
              {mode === 'theory' ? (
                <span className="text-2xl md:text-3xl lg:text-4xl text-blue-400">Meus Fichamentos</span>
              ) : (
                <span className="text-4xl md:text-6xl text-white pl-6 md:pl-10">DOJO</span>
              )}
            </h1>
            
            <button 
              onClick={handleCreate}
              className="group relative flex items-center gap-4 px-6 py-3 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all hover:bg-neutral-50 active:scale-95 shadow-[0_10px_30px_rgba(255,255,255,0.05)] border border-white/10 shrink-0"
            >
              {/* Ícone de Plus Modernizado com Receptáculo Colorido */}
              <div className={`flex items-center justify-center w-7 h-7 rounded-lg transition-all duration-300 ${
                mode === 'theory' 
                  ? 'bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white' 
                  : 'bg-red-50 text-red-600 group-hover:bg-red-700 group-hover:text-white'
              }`}>
                <Plus size={18} strokeWidth={3.5} />
              </div>
              <span className="relative top-[0.5px]">Novo</span>
            </button>
          </div>
          
          <div className="relative mb-3">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
            <input 
              type="text"
              placeholder={mode === 'theory' ? "Buscar fichamento..." : "Buscar matéria no Dojo..."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-neutral-900 border border-neutral-800 rounded-2xl focus:border-neutral-700 focus:ring-1 focus:ring-neutral-700 outline-none text-white placeholder-neutral-600 transition-all font-medium text-sm"
            />
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-4xl mx-auto px-6 py-6 grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {mode === 'training' && (
          filteredSubjects.length === 0 ? (
             <div className="col-span-full py-20 flex flex-col items-center justify-center text-center opacity-60">
               <div className="w-20 h-20 bg-neutral-200 rounded-full flex items-center justify-center mb-6">
                 <Scale size={40} className="text-neutral-400" />
               </div>
               <p className="text-neutral-500 font-bold text-lg mb-2">O Dojo está vazio.</p>
               <button onClick={handleCreate} className="text-red-700 font-bold text-sm hover:underline flex items-center gap-1">
                 Criar Matéria <ArrowRight size={14} />
               </button>
             </div>
          ) : (
            filteredSubjects.map(subject => {
              const subjectLaws = getLawsBySubject(subject.id);
              const totalQuestions = subjectLaws.reduce((acc, law) => acc + (law.cards?.length || 0), 0);
              
              return (
                <div 
                    key={subject.id} 
                    className="bg-white rounded-2xl p-4 md:p-5 border border-neutral-200 shadow-sm hover:shadow-lg hover:border-red-200 transition-all group relative overflow-hidden flex flex-col justify-between"
                    style={{ minHeight: '135px' }}
                >
                    <div className="absolute top-0 right-0 w-20 h-20 bg-red-50 rounded-bl-full -mr-8 -mt-8 pointer-events-none z-0"></div>
                    
                    <div className="relative z-10 flex justify-between items-start">
                        <div className="bg-neutral-100 p-2 rounded-xl text-neutral-700 group-hover:bg-red-700 group-hover:text-white transition-colors">
                            <Scale size={18} />
                        </div>
                        <div className="flex gap-1 relative z-50">
                            <button 
                                onClick={(e) => handleEditSubject(subject, e)}
                                className="p-2 text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 rounded-lg transition-colors"
                            >
                                <Edit3 size={16} />
                            </button>
                            <button 
                                onClick={(e) => handleDelete(subject.id, e)} 
                                className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                                <Trash2 size={16} />
                            </button>
                        </div>
                    </div>

                    <div className="relative z-10 my-2">
                        <h3 className="font-bold text-xl text-neutral-900 leading-tight group-hover:text-red-700 transition-colors truncate">{subject.title}</h3>
                    </div>

                    <div className="relative z-10 flex items-end justify-between mt-auto">
                        <div className="flex flex-col">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 leading-none mb-1">TOTAL</span>
                            <span className="text-sm font-bold text-neutral-700 leading-none">{totalQuestions} questões</span>
                        </div>
                        <button 
                            onClick={() => navigate(`/subject/${subject.id}`)} 
                            className="flex items-center gap-2 px-5 py-2.5 bg-neutral-900 text-white rounded-xl font-bold text-xs shadow-lg shadow-neutral-900/10 hover:bg-red-700 transition-all active:scale-95 cursor-pointer"
                        >
                            <Zap size={14} className="fill-current" /> Treinar
                        </button>
                    </div>
                </div>
              );
            })
          )
        )}

        {mode === 'theory' && (
          filteredTheories.length === 0 ? (
             <div className="col-span-full py-20 flex flex-col items-center justify-center text-center opacity-60">
               <div className="w-20 h-20 bg-neutral-200 rounded-full flex items-center justify-center mb-6">
                 <BookOpen size={40} className="text-neutral-400" />
               </div>
               <p className="text-neutral-500 font-bold text-lg mb-2">Nenhum fichamento encontrado.</p>
               <button onClick={handleCreate} className="text-red-700 font-bold text-sm hover:underline flex items-center gap-1">
                 Importar Arquivo <ArrowRight size={14} />
               </button>
             </div>
          ) : (
            filteredTheories.map(theory => (
              <div key={theory.id} className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-sm hover:shadow-xl hover:shadow-neutral-200/50 hover:border-blue-200 transition-all group relative overflow-hidden cursor-pointer" onClick={() => navigate(`/theory/view/${theory.id}`)}>
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-110 pointer-events-none z-0"></div>
                <div className="relative z-10 flex justify-between items-start mb-4">
                  <div className="bg-neutral-100 p-2.5 rounded-xl text-neutral-700 group-hover:bg-neutral-900 group-hover:text-white transition-colors">
                     <FileText size={24} />
                  </div>
                  <div className="flex gap-1 relative z-50">
                    <button type="button" onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigate(`/theory/edit/${theory.id}`); }} className="p-2 text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 rounded-lg transition-colors"><Edit3 size={18} /></button>
                    <button type="button" onClick={(e) => handleDelete(theory.id, e)} className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 size={18} /></button>
                  </div>
                </div>
                <div className="relative z-10 mb-6">
                  <h3 className="font-bold text-xl text-neutral-900 mb-2 leading-tight group-hover:text-red-700 transition-colors">{theory.title}</h3>
                  <p className="text-sm text-neutral-500 font-bold uppercase tracking-wider">{theory.subject || 'Geral'}</p>
                </div>
                <div className="relative z-10 mt-auto pt-4 border-t border-neutral-100 flex justify-between items-center">
                    <span className="text-[10px] bg-neutral-100 text-neutral-500 px-2 py-1 rounded font-bold uppercase">{theory.contentType?.toUpperCase()}</span>
                    <span className="text-xs font-bold text-red-600 hover:underline flex items-center justify-end gap-1">Ler Fichamento <ArrowRight size={12} /></span>
                </div>
              </div>
            ))
          )
        )}

      </div>
    </div>
  );
};
