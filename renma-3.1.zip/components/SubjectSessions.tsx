
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Plus, Dumbbell, Edit3, Trash2, Search, Zap, Scale, ArrowLeft, ArrowRight, Loader2, Inbox } from 'lucide-react';
import { Law, Subject } from '../types';
import { getSubjectById, getLawsBySubject, createEmptyLaw, saveLaw, deleteLaw } from '../services/storage';

export const SubjectSessions: React.FC = () => {
  const { subjectId } = useParams<{ id: string, subjectId: string }>();
  const navigate = useNavigate();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [laws, setLaws] = useState<Law[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (subjectId) {
      const s = getSubjectById(subjectId);
      if (s) {
        setSubject(s);
        setLaws(getLawsBySubject(subjectId));
      } else {
        navigate('/dashboard');
      }
    }
  }, [subjectId, navigate]);

  const handleCreate = () => {
    if (subjectId) {
      const newLaw = createEmptyLaw(subjectId);
      saveLaw(newLaw);
      navigate(`/edit/${newLaw.id}`);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Excluir esta sessão de treino?')) {
      deleteLaw(id);
      setLaws(prev => prev.filter(l => l.id !== id));
    }
  };

  const filteredLaws = laws.filter(l => 
    l.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    l.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!subject) return <div className="h-screen flex items-center justify-center bg-black text-white"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-neutral-100 pb-20 font-sans">
      {/* Header conforme Print 21/22 */}
      <div className="bg-black text-white sticky top-0 z-30 shadow-lg">
        <div className="max-w-4xl mx-auto px-6 pt-6 pb-10">
          <button 
             onClick={() => navigate('/dashboard')}
             className="flex items-center gap-2 text-neutral-500 hover:text-white mb-6 text-[10px] font-black uppercase tracking-[0.2em] transition-colors"
          >
             <ArrowLeft size={14} /> Voltar ao Dojo
          </button>
          
          <div className="flex items-center justify-between mb-8 gap-4">
            <div className="min-w-0 flex-1 pr-4">
                <h1 className="leading-none select-none flex flex-col">
                    <span className="text-white text-[21px] md:text-[25.2px] font-bold mb-1 pl-[3ch]">
                      Sessões de
                    </span>
                    <span className="text-red-600 text-[21px] md:text-[25.2px] font-black uppercase tracking-tighter pl-[2ch]">
                      TREINAMENTO
                    </span>
                </h1>
            </div>
            
            <button 
              onClick={handleCreate}
              className="group flex items-center gap-3 px-6 py-3 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all hover:bg-neutral-50 active:scale-95 shadow-xl h-12 shrink-0"
            >
              <div className="bg-red-50 text-red-600 p-1 rounded-md group-hover:bg-red-600 group-hover:text-white transition-all">
                <Plus size={16} strokeWidth={3.5} />
              </div>
              <span className="relative top-[0.5px]">Novo</span>
            </button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-neutral-600" size={20} />
            <input 
              type="text"
              placeholder="Pesquisar em seus treinos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-14 pr-6 py-4 bg-neutral-900/50 border border-neutral-800 rounded-[2rem] focus:border-red-600/50 focus:bg-neutral-900 outline-none text-white placeholder-neutral-700 font-medium transition-all text-sm"
            />
          </div>
        </div>
      </div>

      {/* Grid de Cards */}
      <div className="max-w-4xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Card de Novo Treino (Empty State) - Aparece apenas se a lista total for ZERO */}
        {laws.length === 0 && (
          <div className="bg-white rounded-[2.5rem] p-8 border border-neutral-200 shadow-[0_10px_40px_rgba(0,0,0,0.03)] group relative overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-500">
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-50/50 rounded-bl-full -mr-16 -mt-16 pointer-events-none z-0"></div>
              
              <div className="relative z-10 flex justify-between items-start mb-8">
                <div className="bg-neutral-100 p-4 rounded-2xl text-neutral-400">
                   <Scale size={28} />
                </div>
                <div className="flex gap-2">
                  {/* Agora o lápis também aciona o handleCreate para ser mais intuitivo */}
                  <button 
                    onClick={handleCreate}
                    className="p-3 text-neutral-400 hover:text-neutral-800 hover:bg-neutral-50 rounded-xl transition-all"
                    title="Criar novo treino"
                  >
                    <Edit3 size={20} />
                  </button>
                  <div className="p-3 text-neutral-200 cursor-not-allowed">
                    <Trash2 size={20} />
                  </div>
                </div>
              </div>

              <div className="relative mb-10 z-10">
                <h3 className="font-black text-3xl text-neutral-900 mb-2 tracking-tight">Novo Treino</h3>
                <p className="text-sm text-neutral-400 font-medium italic">Comece criando sua primeira sessão de treinamento para esta matéria.</p>
              </div>

              <div className="h-px bg-neutral-100 w-full mb-8"></div>

              <div className="relative z-10 flex items-center justify-between mt-auto">
                 <div className="flex flex-col">
                   <span className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-300 leading-none mb-2">Conteúdo</span>
                   <span className="text-sm font-black text-neutral-800 tracking-tight">0 Questões</span>
                 </div>
                 <button 
                   onClick={handleCreate}
                   className="flex items-center gap-3 px-8 py-4 bg-neutral-900 text-white rounded-[1.2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-black/20 hover:bg-red-700 transition-all active:scale-95"
                 >
                   <Zap size={16} className="fill-current text-yellow-400" /> Iniciar
                 </button>
              </div>
          </div>
        )}

        {/* Listagem de Treinos Existentes */}
        {filteredLaws.map(law => (
          <div key={law.id} className="bg-white rounded-[2.5rem] p-8 border border-neutral-200 shadow-[0_10px_30px_rgba(0,0,0,0.02)] hover:shadow-2xl hover:border-red-200 transition-all group relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-bl-full -mr-16 -mt-16 pointer-events-none z-0"></div>
            
            <div className="relative z-10 flex justify-between items-start mb-8">
              <div className="bg-neutral-100 p-4 rounded-2xl text-neutral-700 group-hover:bg-red-700 group-hover:text-white transition-colors shadow-sm">
                 <Scale size={28} />
              </div>
              <div className="flex gap-2 relative z-50">
                <button onClick={() => navigate(`/edit/${law.id}`)} className="p-3 text-neutral-300 hover:text-neutral-800 hover:bg-neutral-50 rounded-xl transition-all"><Edit3 size={20} /></button>
                <button onClick={(e) => handleDelete(law.id, e)} className="p-3 text-neutral-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={20} /></button>
              </div>
            </div>

            <div className="relative mb-10 z-10">
              <h3 className="font-black text-3xl text-neutral-900 mb-2 tracking-tight group-hover:text-red-700 transition-colors truncate">{law.title}</h3>
              <p className="text-sm text-neutral-400 font-medium line-clamp-2 italic">
                {law.description ? `"${law.description}"` : 'Sem descrição adicional'}
              </p>
            </div>

            <div className="h-px bg-neutral-100 w-full mb-8"></div>

            <div className="relative z-10 flex items-center justify-between mt-auto">
               <div className="flex flex-col">
                 <span className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-300 leading-none mb-2">Conteúdo</span>
                 <span className="text-sm font-black text-neutral-800 tracking-tight">{law.cards.length} Questões</span>
               </div>
               <button onClick={() => navigate(`/study/${law.id}`)} className="flex items-center gap-3 px-8 py-4 bg-neutral-900 text-white rounded-[1.2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-black/20 hover:bg-red-700 transition-all active:scale-95">
                 <Zap size={16} className="fill-current text-yellow-400" /> Iniciar
               </button>
            </div>
          </div>
        ))}

        {/* Feedback caso a busca não retorne nada (e já existam treinos) */}
        {laws.length > 0 && filteredLaws.length === 0 && searchTerm && (
           <div className="col-span-full py-20 flex flex-col items-center justify-center text-neutral-400 animate-in fade-in">
              <Inbox size={48} className="mb-4 opacity-20" />
              <p className="font-bold text-lg">Nenhum treino encontrado para sua busca.</p>
              <p className="text-sm">Tente outro termo ou limpe o campo de pesquisa.</p>
           </div>
        )}
      </div>
    </div>
  );
};
