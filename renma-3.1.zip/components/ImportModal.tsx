import React, { useState } from 'react';
import { X, Upload, FileSpreadsheet, CheckCircle, AlertTriangle, ArrowRight, Clipboard, RefreshCw, AlertCircle, PlusCircle } from 'lucide-react';
import { parseImportData, readFileContent, ImportResult } from '../utils/importHelpers';
import { Card } from '../types';

interface Props {
  onClose: () => void;
  onImport: (cards: Card[]) => void;
  onReplace?: (cards: Card[]) => void;
}

export const ImportModal: React.FC<Props> = ({ onClose, onImport, onReplace }) => {
  const [inputText, setInputText] = useState('');
  const [preview, setPreview] = useState<ImportResult | null>(null);
  const [step, setStep] = useState<'input' | 'preview'>('input');
  
  // State to track if we are appending or replacing
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, mode: 'append' | 'replace') => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const content = await readFileContent(file);
        
        // Update state logic
        setImportMode(mode);
        setInputText(content);
        handleParse(content);
        
        // Permite selecionar o mesmo arquivo novamente se necessário
        e.target.value = '';
      } catch (err) {
        alert('Erro ao ler arquivo.');
      }
    }
  };

  const handleParse = (text: string = inputText) => {
    const result = parseImportData(text);
    setPreview(result);
    setStep('preview');
  };

  const handleConfirm = () => {
    if (preview && preview.cards.length > 0) {
      if (importMode === 'replace' && onReplace) {
         // Executa a substituição imediatamente, sem diálogos de confirmação extras
         // A UI do modal já deixou claro que é uma substituição
         onReplace(preview.cards);
         onClose();
      } else {
         onImport(preview.cards);
         onClose();
      }
    }
  };

  const resetInput = () => {
      setStep('input');
      setInputText('');
      setImportMode('append');
      setPreview(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-in fade-in backdrop-blur-sm">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header Simples */}
        <div className="p-4 border-b border-neutral-100 flex justify-between items-center bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-neutral-100 text-neutral-600">
                {importMode === 'replace' ? <RefreshCw size={20} /> : <FileSpreadsheet size={20} />}
            </div>
            <div>
                <h2 className="font-bold text-lg text-neutral-800">
                    Importar Questões
                </h2>
                <p className="text-xs text-neutral-500">
                    {step === 'input' ? 'Selecione a origem dos dados' : 'Confirme os dados'}
                </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto bg-neutral-50">
          {step === 'input' ? (
            <div className="p-6 space-y-6">
              
              {/* Instructions compactas */}
              <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg text-xs text-blue-800 flex gap-2 items-center">
                <CheckCircle size={14} className="shrink-0" />
                <span className="font-medium">Formato: Pergunta [TAB] Gabarito (V/F) [TAB] Explicação [TAB] Artigo</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Coluna Esquerda: Texto Manual */}
                <div className="flex flex-col h-full">
                   <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm h-full flex flex-col">
                        <label className="text-sm font-bold text-neutral-700 mb-2 flex items-center gap-2">
                           <FileSpreadsheet size={16} className="text-blue-600"/> Opção A: Colar Texto
                        </label>
                        <textarea
                            value={inputText}
                            onChange={(e) => { setInputText(e.target.value); setImportMode('append'); }}
                            className="w-full flex-1 min-h-[140px] p-3 rounded-lg border border-neutral-200 bg-neutral-50 focus:bg-white focus:border-blue-500 outline-none text-xs font-mono resize-none transition-colors"
                            placeholder={`Exemplo:\nO céu é azul\tV\tDevido à dispersão\tCiências\nA terra é plana\tF\tÉ um geoide\tGeografia`}
                        />
                   </div>
                </div>

                {/* Coluna Direita: Botões de Upload */}
                <div className="flex flex-col gap-4">
                   
                   {/* Opção B: Append (Azul/Neutro) */}
                   <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm hover:border-blue-400 transition-colors relative group cursor-pointer flex items-center gap-4">
                        <input 
                            type="file" 
                            accept=".csv,.txt" 
                            onChange={(e) => handleFileUpload(e, 'append')}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                        />
                        <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <PlusCircle size={20} />
                        </div>
                        <div className="min-w-0">
                            <span className="text-sm font-bold text-neutral-800 block">Opção B: Adicionar</span>
                            <span className="text-xs text-neutral-500 truncate block">Soma novas questões à lista atual.</span>
                        </div>
                   </div>

                   {/* Opção C: Replace (Laranja/Amber - Destaque suave, sem vermelho) */}
                   {onReplace && (
                       <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-sm hover:border-amber-400 transition-colors relative group cursor-pointer flex items-center gap-4">
                            <input 
                                type="file" 
                                accept=".csv,.txt" 
                                onChange={(e) => handleFileUpload(e, 'replace')}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                            />
                            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                                <RefreshCw size={20} />
                            </div>
                            <div className="min-w-0">
                                <span className="text-sm font-bold text-neutral-800 block">Opção C: Substituir Tudo</span>
                                <span className="text-xs text-neutral-500 truncate block">Apaga a lista atual e importa o arquivo.</span>
                            </div>
                       </div>
                   )}
                </div>
              </div>
            </div>
          ) : (
            // Preview Step
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-neutral-200 shadow-sm">
                <div className="flex items-center gap-3">
                    <div className="bg-emerald-100 text-emerald-700 p-2 rounded-lg">
                        <CheckCircle size={18} />
                    </div>
                    <div>
                        <p className="font-bold text-sm text-neutral-800">{preview?.successCount} questões encontradas</p>
                        {preview?.errors && preview.errors.length > 0 && (
                            <p className="text-xs text-rose-500">{preview.errors.length} linhas ignoradas</p>
                        )}
                    </div>
                </div>
                {importMode === 'replace' && (
                    <div className="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-bold border border-amber-200">
                        Modo: Substituição
                    </div>
                )}
              </div>

              {/* Tabela Simplificada */}
              <div className="border border-neutral-200 rounded-xl overflow-hidden bg-white">
                <div className="max-h-[350px] overflow-y-auto">
                    <table className="w-full text-sm text-left">
                    <thead className="bg-neutral-100 text-neutral-600 font-bold uppercase text-xs sticky top-0">
                        <tr>
                        <th className="p-3">Enunciado</th>
                        <th className="p-3 w-20 text-center">Resp.</th>
                        <th className="p-3 w-1/3">Explicação</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                        {preview?.cards.slice(0, 50).map((card, idx) => (
                        <tr key={idx} className="hover:bg-neutral-50">
                            <td className="p-3 align-top text-neutral-800">{card.text}</td>
                            <td className="p-3 align-top text-center">
                                <span className={`font-bold text-xs px-2 py-1 rounded ${card.isTrue ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                    {card.isTrue ? 'C' : 'E'}
                                </span>
                            </td>
                            <td className="p-3 align-top text-neutral-500 text-xs">{card.explanation}</td>
                        </tr>
                        ))}
                    </tbody>
                    </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-neutral-100 bg-white flex justify-end gap-3">
          {step === 'preview' && (
             <button 
              onClick={resetInput}
              className="px-4 py-2 text-neutral-500 font-bold hover:bg-neutral-100 rounded-lg transition-colors text-sm"
            >
              Voltar
            </button>
          )}
          
          {step === 'input' ? (
            <button 
              onClick={() => handleParse()}
              disabled={!inputText.trim()}
              className="px-6 py-2 bg-neutral-900 text-white rounded-lg font-bold hover:bg-black disabled:opacity-50 text-sm transition-all"
            >
              Processar Texto
            </button>
          ) : (
            <button 
              onClick={handleConfirm}
              disabled={!preview?.cards.length}
              className={`flex items-center gap-2 px-6 py-2 text-white rounded-lg font-bold shadow-md transition-all active:scale-95 text-sm ${
                  importMode === 'replace' 
                  ? 'bg-amber-500 hover:bg-amber-600' 
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {importMode === 'replace' ? (
                 <> <RefreshCw size={16} /> Confirmar Substituição </>
              ) : (
                 <> <Clipboard size={16} /> Confirmar Importação </>
              )}
            </button>
          )}
        </div>

      </div>
    </div>
  );
};