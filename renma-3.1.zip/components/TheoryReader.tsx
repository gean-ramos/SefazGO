import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit3, BookOpen, Settings, Type, Sun, Moon, Eye, Play, Pause, SkipForward, X, Volume2, Loader2, AlertCircle, Download, FileText, ExternalLink, Mic, CloudDownload, ChevronUp, Trash2 } from 'lucide-react';
import { getTheoryById, deleteTheory } from '../services/storage';
import { getFile } from '../services/fileStorage';
import { generateSpeech } from '../services/geminiService';
import { Theory } from '../types';
import { pcmToWav } from '../utils/audioHelpers';

type Theme = 'light' | 'dark' | 'contrast';
type VoiceType = 'native' | 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';

export const TheoryReader: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [theory, setTheory] = useState<Theory | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [loadingFile, setLoadingFile] = useState(false);
  
  // Appearance State (HTML Only)
  const [fontSize, setFontSize] = useState(18);
  const [theme, setTheme] = useState<Theme>('light');
  const [showSettings, setShowSettings] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<VoiceType>('Puck');

  // Audio State (HTML Only)
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [isGeneratingDownload, setIsGeneratingDownload] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [readingIndex, setReadingIndex] = useState<number | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  
  const contentRef = useRef<HTMLDivElement>(null);
  const textBlocksRef = useRef<HTMLElement[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const currentSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const audioCacheRef = useRef<Map<number, AudioBuffer>>(new Map());
  const activeFetchesRef = useRef<Map<number, Promise<void>>>(new Map());

  useEffect(() => {
    if (id) {
      const data = getTheoryById(id);
      if (data) {
        setTheory(data);
        if ((data.contentType === 'pdf' || data.contentType === 'docx') && data.hasExternalPdf) {
            loadFileFromDB(data.id);
        } else if (data.contentType === 'pdf' && data.pdfContent) {
            setFileUrl(data.pdfContent);
        }
      } else {
        navigate('/dashboard');
      }
    }
    
    return () => {
      stopAllAudio();
      if (fileUrl && !fileUrl.startsWith('data:')) {
          URL.revokeObjectURL(fileUrl);
      }
    };
  }, [id, navigate]);

  const loadFileFromDB = async (theoryId: string) => {
      setLoadingFile(true);
      try {
          const blob = await getFile(theoryId);
          if (blob) {
              const url = URL.createObjectURL(blob);
              setFileUrl(url);
          } else {
              console.error("File not found in DB");
          }
      } catch (e) {
          console.error("Error loading File", e);
      } finally {
          setLoadingFile(false);
      }
  }

  useEffect(() => {
    // Re-scan text blocks when content loads or changes (HTML Only)
    if (theory?.contentType === 'html' && contentRef.current) {
      setTimeout(() => {
        if (contentRef.current) {
          const elements = contentRef.current.querySelectorAll('h1, h2, h3, h4, p, li, blockquote');
          textBlocksRef.current = Array.from(elements) as HTMLElement[];
          audioCacheRef.current.clear();
          activeFetchesRef.current.clear();
        }
      }, 100); 
    }
  }, [theory?.htmlContent, theory?.contentType]);

  const handleDeleteTheory = () => {
      if (!theory) return;
      if (window.confirm(`Tem certeza que deseja excluir permanentemente o fichamento "${theory.title}"? Esta ação não pode ser desfeita.`)) {
          deleteTheory(theory.id);
          navigate('/dashboard');
      }
  };

  const initAudioContext = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    return audioContextRef.current;
  };

  const stopAllAudio = () => {
    window.speechSynthesis.cancel();
    if (currentSourceRef.current) {
      try {
        currentSourceRef.current.stop();
        currentSourceRef.current.disconnect();
      } catch (e) { /* ignore */ }
      currentSourceRef.current = null;
    }
    setIsPlaying(false);
    setIsPaused(false);
    setIsLoadingAudio(false);
  };

  const decodePCM = (arrayBuffer: ArrayBuffer, ctx: AudioContext): AudioBuffer => {
    const dataInt16 = new Int16Array(arrayBuffer);
    const frameCount = dataInt16.length;
    const buffer = ctx.createBuffer(1, frameCount, 24000); 
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
  };

  const prefetchAudio = async (index: number) => {
    if (!textBlocksRef.current[index]) return;
    if (audioCacheRef.current.has(index)) return;
    if (activeFetchesRef.current.has(index)) return;

    const text = textBlocksRef.current[index].innerText.trim();
    if (!text) return; 

    const fetchPromise = (async () => {
      try {
        const pcmData = await generateSpeech(text, selectedVoice === 'native' ? 'Puck' : selectedVoice);
        if (pcmData) {
          const ctx = initAudioContext();
          const buffer = decodePCM(pcmData, ctx);
          audioCacheRef.current.set(index, buffer);
        }
      } catch (err) {
        console.error(`Error pre-fetching index ${index}`, err);
      } finally {
        activeFetchesRef.current.delete(index);
      }
    })();

    activeFetchesRef.current.set(index, fetchPromise);
  };

  const handlePlay = () => {
    if (isPaused) {
      if (selectedVoice === 'native') window.speechSynthesis.resume();
      else if (audioContextRef.current?.state === 'suspended') audioContextRef.current.resume();
      setIsPaused(false);
      setIsPlaying(true);
      return;
    }

    if (readingIndex !== null) return;
    startReading(0);
  };

  const startReading = async (index: number) => {
    if (!textBlocksRef.current[index]) {
      stopAllAudio();
      setReadingIndex(null);
      return;
    }

    setReadingIndex(index);
    setIsPlaying(true);
    setIsPaused(false);

    const element = textBlocksRef.current[index];
    const text = element.innerText.trim();
    element.scrollIntoView({ behavior: 'smooth', block: 'center' });

    if (selectedVoice === 'native') {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'pt-BR';
      utterance.rate = 1.1;
      utterance.onend = () => startReading(index + 1);
      utterance.onerror = () => setIsPlaying(false);
      window.speechSynthesis.speak(utterance);
      return;
    }

    const ctx = initAudioContext();
    prefetchAudio(index + 1);
    prefetchAudio(index + 2);

    let audioBuffer = audioCacheRef.current.get(index);

    if (!audioBuffer) {
      setIsLoadingAudio(true);
      if (activeFetchesRef.current.has(index)) {
        await activeFetchesRef.current.get(index);
      } else {
        await prefetchAudio(index);
      }
      audioBuffer = audioCacheRef.current.get(index);
      setIsLoadingAudio(false);
    }

    if (!audioBuffer) {
      startReading(index + 1);
      return;
    }

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);
    
    source.onended = () => {
       if (currentSourceRef.current === source) {
         startReading(index + 1);
       }
    };

    if (currentSourceRef.current) {
      try { 
        currentSourceRef.current.stop(); 
        currentSourceRef.current.disconnect();
      } catch(e){}
    }
    
    currentSourceRef.current = source;
    source.start();
  };

  const handlePause = () => {
    if (selectedVoice === 'native') window.speechSynthesis.pause();
    else if (audioContextRef.current) audioContextRef.current.suspend();
    setIsPaused(true);
    setIsPlaying(false);
  };

  const handleSkip = () => {
    if (selectedVoice === 'native') window.speechSynthesis.cancel();
    if (currentSourceRef.current) {
        try { 
            currentSourceRef.current.stop(); 
            currentSourceRef.current.disconnect();
        } catch(e){}
    }
    if (readingIndex !== null) startReading(readingIndex + 1);
    else startReading(0);
  };

  const handleStop = () => {
    stopAllAudio();
    setReadingIndex(null);
  };

  // --- NEW: Audio Download Logic ---
  const handleDownloadAudio = async () => {
    if (selectedVoice === 'native') {
        alert("O download de áudio só está disponível para as vozes de Inteligência Artificial (Puck, Kore, etc).");
        return;
    }

    if (textBlocksRef.current.length === 0) {
        alert("Nenhum texto detectado para leitura.");
        return;
    }

    setIsGeneratingDownload(true);
    stopAllAudio();
    setDownloadProgress(0);

    const allPcmChunks: Float32Array[] = [];
    let totalLength = 0;

    try {
        const blocks = textBlocksRef.current;
        for (let i = 0; i < blocks.length; i++) {
            const text = blocks[i].innerText.trim();
            if (text) {
                // Fetch PCM data
                const rawBuffer = await generateSpeech(text, selectedVoice);
                if (rawBuffer) {
                    const dataInt16 = new Int16Array(rawBuffer);
                    // Convert to float for processing/combining (simplifies logic reuse)
                    const float32 = new Float32Array(dataInt16.length);
                    for(let j=0; j<dataInt16.length; j++) {
                        float32[j] = dataInt16[j] / 32768.0;
                    }
                    allPcmChunks.push(float32);
                    totalLength += float32.length;
                }
            }
            // Update progress
            setDownloadProgress(Math.round(((i + 1) / blocks.length) * 100));
        }

        // Concatenate all chunks
        const finalPcm = new Float32Array(totalLength);
        let offset = 0;
        for (const chunk of allPcmChunks) {
            finalPcm.set(chunk, offset);
            offset += chunk.length;
        }

        // Convert to WAV
        const wavBuffer = pcmToWav(finalPcm, 24000);
        const blob = new Blob([wavBuffer], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        
        // Trigger Download
        const a = document.createElement('a');
        a.href = url;
        a.download = `${theory?.title || 'audio'}-${selectedVoice}.wav`;
        a.click();
        URL.revokeObjectURL(url);

    } catch (error) {
        console.error("Download generation failed", error);
        alert("Erro ao gerar áudio completo. Tente novamente.");
    } finally {
        setIsGeneratingDownload(false);
        setDownloadProgress(0);
    }
  };

  const getThemeStyles = () => {
    switch (theme) {
      case 'dark': return 'bg-neutral-900 text-neutral-300';
      case 'contrast': return 'bg-black text-yellow-400';
      default: return 'bg-white text-neutral-900';
    }
  };

  const getContainerStyles = () => {
    switch (theme) {
      case 'dark': return 'bg-neutral-950';
      case 'contrast': return 'bg-black';
      default: return 'bg-neutral-100';
    }
  };

  if (!theory) return null;
  
  const isBinaryFile = theory.contentType === 'pdf' || theory.contentType === 'docx';

  return (
    <div className={`min-h-screen font-sans ${isBinaryFile ? 'h-screen overflow-hidden' : 'pb-40'} transition-colors duration-300 ${getContainerStyles()}`}>
      
      {/* Header */}
      <div className={`${theme === 'light' ? 'bg-black text-white' : 'bg-neutral-900 text-white border-b border-neutral-800'} sticky top-0 z-30 shadow-lg transition-colors`}>
        <div className="max-w-4xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/dashboard')} className="p-2 -ml-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-full transition-colors">
              <ArrowLeft size={20} />
            </button>
            <h1 className="font-bold text-lg truncate max-w-[150px] sm:max-w-md">{theory.title}</h1>
          </div>
          
          <div className="flex items-center gap-2">
            {!isBinaryFile && (
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className={`p-2 rounded-lg transition-colors ${showSettings ? 'bg-white text-black' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'}`}
                title="Aparência"
              >
                <Settings size={20} />
              </button>
            )}
            
            <button 
                onClick={handleDeleteTheory}
                className="p-2 text-neutral-400 hover:text-red-500 hover:bg-neutral-800 rounded-lg transition-colors"
                title="Excluir Fichamento"
            >
                <Trash2 size={20} />
            </button>

            <button 
              onClick={() => navigate(`/theory/edit/${theory.id}`)}
              className="p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white rounded-lg transition-colors"
              title="Editar"
            >
              <Edit3 size={20} />
            </button>
          </div>
        </div>

        {/* Settings Toolbar (Only for HTML content) */}
        {showSettings && !isBinaryFile && (
          <div className="border-t border-neutral-800 bg-neutral-900 p-4 animate-in slide-in-from-top-2 shadow-2xl">
             <div className="max-w-4xl mx-auto flex flex-col gap-4">
              <div className="flex flex-wrap gap-4 justify-between items-center">
                <div className="flex items-center gap-3 bg-neutral-800 p-2 rounded-xl">
                  <button onClick={() => setFontSize(Math.max(14, fontSize - 2))} className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-700 rounded-lg"><Type size={14} /></button>
                  <span className="text-white font-mono text-sm w-8 text-center">{fontSize}</span>
                  <button onClick={() => setFontSize(Math.min(32, fontSize + 2))} className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-700 rounded-lg"><Type size={20} /></button>
                </div>
                <div className="flex items-center gap-2 bg-neutral-800 p-2 rounded-xl">
                  <button onClick={() => setTheme('light')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${theme === 'light' ? 'bg-white text-black' : 'text-neutral-400 hover:text-white'}`}><Sun size={14} /> Claro</button>
                  <button onClick={() => setTheme('dark')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${theme === 'dark' ? 'bg-black text-white' : 'text-neutral-400 hover:text-white'}`}><Moon size={14} /> Escuro</button>
                  <button onClick={() => setTheme('contrast')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${theme === 'contrast' ? 'bg-yellow-400 text-black' : 'text-neutral-400 hover:text-white'}`}><Eye size={14} /> Contraste</button>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-neutral-500 uppercase flex items-center gap-2"><Mic size={12}/> Voz do Narrador</label>
                  <div className="flex gap-2 flex-wrap">
                      {['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'].map(v => (
                          <button 
                            key={v}
                            onClick={() => setSelectedVoice(v as VoiceType)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedVoice === v ? 'bg-red-700 text-white border-red-700' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:border-neutral-500'}`}
                          >
                              {v}
                          </button>
                      ))}
                       <button 
                            onClick={() => setSelectedVoice('native')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedVoice === 'native' ? 'bg-white text-black border-white' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:border-neutral-500'}`}
                          >
                              Nativa (Offline)
                       </button>
                  </div>
              </div>
              
              {/* Botão de Recolher */}
              <button
                onClick={() => setShowSettings(false)}
                className="w-full flex items-center justify-center mt-2 pt-3 border-t border-neutral-800 text-neutral-500 hover:text-white hover:bg-neutral-800 transition-colors py-1"
                title="Recolher menu"
              >
                <ChevronUp size={20} />
              </button>

            </div>
          </div>
        )}
      </div>

      <main className={`max-w-4xl mx-auto ${isBinaryFile ? 'h-[calc(100vh-64px)] flex flex-col' : 'px-4 py-6'}`}>
        {loadingFile ? (
            <div className="flex flex-col items-center justify-center h-full text-neutral-400">
                <Loader2 size={48} className="animate-spin mb-4 text-red-700" />
                <p>Carregando documento...</p>
            </div>
        ) : (
            isBinaryFile ? (
               theory.contentType === 'docx' ? (
                 <div className="flex flex-col items-center justify-center h-full text-neutral-400 p-8 text-center">
                    <div className="w-24 h-24 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-6">
                       <FileText size={48} />
                    </div>
                    <h2 className="text-2xl font-bold text-neutral-800 mb-2">{theory.title}</h2>
                    <p className="max-w-md mb-8">
                      Este é um arquivo Word (.docx). O navegador não suporta a visualização direta deste formato.
                    </p>
                    {fileUrl ? (
                      <a 
                        href={fileUrl} 
                        download={`${theory.title}.docx`}
                        className="flex items-center gap-2 px-8 py-4 bg-neutral-900 text-white font-bold rounded-xl shadow-lg hover:bg-neutral-800 transition-all"
                      >
                        <Download size={20} /> Baixar Arquivo
                      </a>
                    ) : (
                      <p className="text-red-500 flex items-center gap-2"><AlertCircle size={16} /> Arquivo não encontrado.</p>
                    )}
                 </div>
               ) : (
                 fileUrl ? (
                    <div className="flex flex-col h-full bg-neutral-100">
                        <div className="flex justify-between items-center px-4 py-2 bg-white border-b border-neutral-200">
                            <span className="text-xs font-bold text-neutral-500 uppercase">Visualizador de PDF</span>
                            <div className="flex gap-4">
                                 <a href={fileUrl} target="_blank" rel="noreferrer" className="text-xs font-bold text-neutral-600 hover:text-red-700 flex items-center gap-1">
                                     <ExternalLink size={14} /> Expandir / Nova Aba
                                 </a>
                                 <a href={fileUrl} download={`${theory.title}.pdf`} className="text-xs font-bold text-neutral-600 hover:text-red-700 flex items-center gap-1">
                                     <Download size={14} /> Baixar
                                 </a>
                            </div>
                        </div>
                        <iframe 
                            src={fileUrl}
                            className="w-full flex-1 border-0"
                            title="Leitor de PDF"
                        />
                    </div>
                 ) : (
                    <div className="flex flex-col items-center justify-center h-full text-neutral-400">
                        <AlertCircle size={48} className="mb-4" />
                        <p>Documento PDF não encontrado.</p>
                    </div>
                 )
               )
            ) : (
              // HTML Viewer
              <div className={`shadow-xl min-h-[80vh] p-8 md:p-16 rounded-sm max-w-[210mm] mx-auto transition-colors duration-300 ${getThemeStyles()} ${theme === 'contrast' ? 'border-2 border-yellow-400' : ''}`}>
                 <div className={`border-b-2 pb-6 mb-8 ${theme === 'contrast' ? 'border-yellow-400/30' : 'border-neutral-200/50'}`}>
                   <h1 className="text-3xl font-bold mb-2">{theory.title}</h1>
                   <p className={`font-medium uppercase tracking-widest text-xs flex items-center gap-2 ${theme === 'contrast' ? 'text-yellow-600' : 'text-red-700'}`}>
                     <BookOpen size={14} /> {theory.subject || 'Sem categoria'}
                   </p>
                 </div>

                 <div 
                   ref={contentRef}
                   style={{ fontSize: `${fontSize}px`, lineHeight: '1.8' }}
                   className={`prose max-w-none font-serif transition-colors
                      ${theme === 'dark' ? 'prose-invert prose-headings:text-neutral-100 prose-p:text-neutral-300 prose-strong:text-white' : ''}
                      ${theme === 'contrast' ? 'prose-headings:text-yellow-400 prose-p:text-yellow-400 prose-strong:text-yellow-300 prose-li:text-yellow-400 decoration-yellow-400' : ''}
                      ${theme === 'light' ? 'prose-neutral prose-headings:text-neutral-900 prose-p:text-neutral-800' : ''}
                   `}
                   dangerouslySetInnerHTML={{ __html: theory.htmlContent || '' }}
                 />
              </div>
            )
        )}
      </main>

      {/* Audio Player Bar (Hidden for Binary Files) */}
      {!isBinaryFile && (
        <div className={`fixed bottom-0 left-0 right-0 p-4 z-40 ${
          theme === 'contrast' ? 'bg-yellow-400 border-t-4 border-black' : 'bg-white border-t border-neutral-200 shadow-[0_-10px_40px_rgba(0,0,0,0.1)]'
        }`}>
          <div className="max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            
            <div className="flex items-center gap-3 overflow-hidden w-full sm:w-auto">
              <div className={`p-3 rounded-xl flex items-center justify-center shrink-0 ${theme === 'contrast' ? 'bg-black text-yellow-400' : 'bg-neutral-900 text-white'}`}>
                 {isLoadingAudio || isGeneratingDownload ? <Loader2 size={24} className="animate-spin" /> : <Volume2 size={24} className={isPlaying ? 'animate-pulse' : ''} />}
              </div>
              <div className="min-w-0">
                <p className={`text-xs font-bold uppercase tracking-wider truncate ${theme === 'contrast' ? 'text-black' : 'text-neutral-400'}`}>
                  {isGeneratingDownload ? `Gerando Download (${downloadProgress}%)` : (selectedVoice === 'native' ? 'Voz Nativa' : `Voz: ${selectedVoice}`)}
                </p>
                <p className={`font-bold truncate ${theme === 'contrast' ? 'text-black' : 'text-neutral-900'}`}>
                  {isGeneratingDownload ? 'Processando áudio...' : (readingIndex !== null ? (isLoadingAudio ? 'Carregando...' : 'Reproduzindo...') : 'Pausado')}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
               
               {/* Download Button */}
               <button 
                 onClick={handleDownloadAudio}
                 disabled={isGeneratingDownload || isLoadingAudio || isPlaying}
                 className={`p-3 rounded-full transition-colors ${
                   theme === 'contrast' 
                     ? 'hover:bg-black/10 text-black' 
                     : 'hover:bg-neutral-100 text-neutral-600 disabled:opacity-30'
                 }`}
                 title="Baixar áudio completo da leitura"
               >
                 <CloudDownload size={24} />
               </button>

               <div className="w-px h-8 bg-neutral-200 mx-1"></div>

               <button 
                 onClick={isPlaying ? handlePause : handlePlay}
                 disabled={isGeneratingDownload}
                 className={`w-12 h-12 flex items-center justify-center rounded-full transition-all active:scale-95 shadow-lg ${
                   theme === 'contrast' 
                     ? 'bg-black text-yellow-400 hover:bg-neutral-800' 
                     : 'bg-red-700 text-white hover:bg-red-800 shadow-red-900/20 disabled:opacity-50 disabled:shadow-none'
                 }`}
               >
                 {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
               </button>
               
               <button 
                 onClick={handleSkip}
                 disabled={isGeneratingDownload}
                 className={`p-3 rounded-full transition-colors ${
                   theme === 'contrast' 
                     ? 'hover:bg-black/10 text-black' 
                     : 'hover:bg-neutral-100 text-neutral-600 disabled:opacity-30'
                 }`}
               >
                 <SkipForward size={24} />
               </button>

               {readingIndex !== null && (
                 <button 
                   onClick={handleStop}
                   className={`p-3 rounded-full transition-colors ${
                     theme === 'contrast' 
                       ? 'hover:bg-black/10 text-black' 
                       : 'hover:bg-neutral-100 text-neutral-400 hover:text-red-600'
                   }`}
                 >
                   <X size={20} />
                 </button>
               )}
            </div>

          </div>
        </div>
      )}
      
      {!isBinaryFile && readingIndex !== null && (
        <EffectHighlighter index={readingIndex} blocks={textBlocksRef.current} />
      )}
    </div>
  );
};

const EffectHighlighter: React.FC<{index: number, blocks: HTMLElement[]}> = ({ index, blocks }) => {
  useEffect(() => {
    blocks.forEach(b => b.classList.remove('reading-highlight'));
    if (blocks[index]) {
      blocks[index].classList.add('reading-highlight');
    }
    return () => {
      if (blocks[index]) blocks[index].classList.remove('reading-highlight');
    }
  }, [index, blocks]);
  return null;
};