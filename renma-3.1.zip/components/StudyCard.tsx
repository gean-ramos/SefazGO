import React, { useState, useEffect } from 'react';
import { Card, AnswerStatus, MasteryLevel } from '../types';
import { Check, X, ArrowRight, ArrowLeft, Shuffle, Bot, Bookmark, Star } from 'lucide-react';
import { explainCard } from '../services/geminiService';

interface Props {
  card: Card;
  total: number;
  current: number;
  onNext: () => void;
  onPrev: () => void;
  onShuffle: () => void;
  onResult: (isCorrect: boolean) => void;
  onToggleFavorite: (cardId: string) => void;
}

export const StudyCard: React.FC<Props> = ({ card, total, current, onNext, onPrev, onShuffle, onResult, onToggleFavorite }) => {
  const [status, setStatus] = useState<AnswerStatus>('unanswered');
  const [userGuess, setUserGuess] = useState<boolean | null>(null);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  useEffect(() => {
    setStatus('unanswered');
    setUserGuess(null);
    setAiExplanation(null);
    setIsLoadingAi(false);
  }, [card]);

  const handleAnswer = (guessIsTrue: boolean) => {
    setUserGuess(guessIsTrue);
    const isCorrect = guessIsTrue === card.isTrue;
    
    if (isCorrect) {
      setStatus('correct');
    } else {
      setStatus('incorrect');
    }
    
    // Notify parent to save stats
    onResult(isCorrect);
  };

  const handleAskAI = async () => {
    setIsLoadingAi(true);
    const explanation = await explainCard(card.text, card.explanation, card.isTrue);
    setAiExplanation(explanation);
    setIsLoadingAi(false);
  };

  const isAnswered = status !== 'unanswered';

  const getBadgeColor = (level: MasteryLevel) => {
    switch (level) {
      case MasteryLevel.EASY: return 'bg-neutral-100 text-neutral-600 border-neutral-200';
      case MasteryLevel.LITERAL: return 'bg-blue-50 text-blue-700 border-blue-200';
      case MasteryLevel.MEDIUM: return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case MasteryLevel.HARD: return 'bg-orange-50 text-orange-700 border-orange-200';
      case MasteryLevel.ADVANCED: return 'bg-red-50 text-red-700 border-red-200';
      default: return 'bg-neutral-100 text-neutral-500';
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pb-24 font-sans">
      
      {/* Top Controls / Metadata */}
      <div className="flex flex-wrap items-center justify-between mb-6 mt-4">
        <div className="flex items-center gap-2">
            <div className="h-10 w-10 bg-neutral-900 rounded-full flex items-center justify-center text-white font-bold shadow-lg shadow-neutral-400/20">
                {current}
            </div>
            <div className="flex flex-col">
                <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Questão</span>
                <span className="text-xs font-bold text-neutral-600">de {total}</span>
            </div>
        </div>

        <div className="flex items-center gap-2">
             <span className={`px-3 py-1.5 border rounded-lg text-xs font-bold shadow-sm uppercase tracking-wide ${getBadgeColor(card.mastery)}`}>
              {card.mastery}
            </span>
             
             {/* Star Button replacing previous label */}
             <button 
                onClick={() => onToggleFavorite(card.id)}
                className="p-1.5 rounded-lg border border-neutral-200 bg-white hover:bg-yellow-50 hover:border-yellow-300 transition-colors shadow-sm group"
                title={card.isFavorite ? "Remover dos Favoritos" : "Adicionar aos Favoritos"}
             >
                <Star 
                  size={18} 
                  className={`transition-all ${card.isFavorite ? 'fill-yellow-400 text-yellow-400' : 'text-neutral-300 group-hover:text-yellow-400'}`} 
                />
             </button>
        </div>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl shadow-xl shadow-neutral-200/50 border border-neutral-100 overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-600 to-neutral-800"></div>
        
        <div className="p-8 md:p-10">
          <h3 className="text-xl md:text-2xl font-medium text-neutral-800 leading-relaxed">
            {card.text}
          </h3>
        </div>

        {/* Answer Section */}
        <div className="px-8 pb-8">
          <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-4 flex items-center gap-2">
             <span className="w-8 h-px bg-neutral-200"></span>
             Julgue o item
             <span className="w-8 h-px bg-neutral-200"></span>
          </p>
          
          <div className="grid grid-cols-2 gap-4">
            <button
              disabled={isAnswered}
              onClick={() => handleAnswer(true)}
              className={`flex items-center justify-center gap-2 py-4 rounded-2xl font-bold transition-all ${
                isAnswered 
                  ? userGuess === true 
                    ? (status === 'correct' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' : 'bg-neutral-100 text-neutral-400')
                    : 'bg-neutral-50 text-neutral-200'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white border-2 border-transparent hover:border-emerald-700 active:scale-95'
              }`}
            >
              <Check size={20} strokeWidth={3} />
              CERTO
            </button>
            <button
              disabled={isAnswered}
              onClick={() => handleAnswer(false)}
              className={`flex items-center justify-center gap-2 py-4 rounded-2xl font-bold transition-all ${
                 isAnswered 
                  ? userGuess === false
                    ? (status === 'correct' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' : 'bg-neutral-100 text-neutral-400')
                    : 'bg-neutral-50 text-neutral-200'
                  : 'bg-red-50 text-red-700 hover:bg-red-600 hover:text-white border-2 border-transparent hover:border-red-700 active:scale-95'
              }`}
            >
              <X size={20} strokeWidth={3} />
              ERRADO
            </button>
          </div>
        </div>

        {/* Embedded Navigation Bar */}
        <div className="bg-neutral-50 border-t border-neutral-100 p-6">
          <div className="flex items-center justify-between gap-4">
            
            {/* Setinha Esquerda (Voltar) */}
            <button 
              onClick={onPrev} 
              disabled={current === 1} 
              className="h-14 w-20 flex items-center justify-center rounded-2xl bg-white border-2 border-neutral-200 text-neutral-400 hover:border-neutral-400 hover:text-neutral-800 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-sm active:scale-95"
              title="Questão Anterior"
            >
              <ArrowLeft size={24} strokeWidth={2.5} />
            </button>
            
            {/* Setinhas Cruzadas (Shuffle) */}
            <button 
              onClick={onShuffle} 
              className="h-14 flex-1 flex items-center justify-center gap-2 rounded-2xl bg-white border-2 border-neutral-200 text-neutral-600 font-bold hover:bg-neutral-200 hover:border-neutral-300 hover:text-neutral-900 transition-all active:scale-95 shadow-sm" 
              title="Embaralhar Questões"
            >
                <Shuffle size={20} strokeWidth={2.5} />
                <span className="text-sm uppercase tracking-wider hidden sm:inline">Aleatório</span>
            </button>

            {/* Setinha Direita (Avançar/Pular) */}
            <button 
              onClick={onNext} 
              className={`h-14 w-20 flex items-center justify-center rounded-2xl text-white shadow-lg transition-all active:scale-95 ${
                 isAnswered 
                 ? 'bg-neutral-900 hover:bg-neutral-800 shadow-neutral-900/20' 
                 : 'bg-red-700 hover:bg-red-800 shadow-red-900/20'
              }`}
              title="Próxima Questão"
            >
               <ArrowRight size={24} strokeWidth={2.5} />
            </button>
          </div>
        </div>
      </div>

      {/* Result Feedback & Explanation */}
      {isAnswered && (
        <div className="mt-8 animate-in slide-in-from-bottom-8 duration-500 ease-out">
          
          {/* Feedback Banner */}
          <div className={`p-5 rounded-2xl flex items-center gap-4 mb-6 shadow-sm border-l-4 ${
            status === 'correct' 
              ? 'bg-white border-l-emerald-500 text-emerald-800' 
              : 'bg-white border-l-red-500 text-red-800'
          }`}>
            <div className={`p-2 rounded-full shrink-0 ${status === 'correct' ? 'bg-emerald-100' : 'bg-red-100'}`}>
              {status === 'correct' ? <Check size={20} /> : <X size={20} />}
            </div>
            <div className="flex-1">
              <p className="font-bold text-lg leading-none mb-1">
                {status === 'correct' ? 'Resposta Correta!' : 'Resposta Incorreta'}
              </p>
              <p className="text-sm opacity-80">
                Gabarito oficial: <strong>{card.isTrue ? 'CERTO' : 'ERRADO'}</strong>
              </p>
            </div>
          </div>

          {/* Legal Text Explanation */}
          <div className="bg-neutral-900 rounded-2xl p-6 text-neutral-300 relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                <Bookmark size={120} />
             </div>
             
             <h4 className="text-xs font-bold text-red-500 uppercase tracking-widest mb-3 flex items-center gap-2">
               Justificativa
             </h4>
             
             <div className="bg-neutral-800/50 p-4 rounded-xl border border-neutral-700 mb-4">
               <span className="text-red-400 font-bold block text-sm mb-2">{card.articleId}</span>
               <p className="text-neutral-200 leading-relaxed font-serif text-lg italic">
                 "{card.explanation}"
               </p>
             </div>

             {/* AI Explanation Button */}
             {!aiExplanation ? (
               <button 
                 onClick={handleAskAI}
                 disabled={isLoadingAi}
                 className="mt-2 w-full flex items-center justify-center gap-2 text-sm font-bold text-neutral-900 bg-white hover:bg-neutral-200 px-4 py-3 rounded-xl transition-colors shadow-lg"
               >
                 <Bot size={18} className={isLoadingAi ? "animate-pulse" : "text-red-600"} />
                 {isLoadingAi ? "Consultando IA..." : "Pedir explicação detalhada à IA"}
               </button>
             ) : (
                <div className="mt-4 bg-neutral-800 rounded-xl p-5 border border-neutral-700 animate-in fade-in">
                    <h4 className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                      <Bot size={14} /> Arcádia AI
                    </h4>
                    <p className="text-neutral-300 text-sm leading-relaxed">
                      {aiExplanation}
                    </p>
                </div>
             )}
          </div>
        </div>
      )}
    </div>
  );
};