import React, { useState, useRef, useEffect } from 'react';
import { Note } from '../types';
import { Flame, Snowflake, X, StickyNote } from 'lucide-react';

interface Props {
  htmlContent: string;
  notes: Note[];
  onUpdate: (newHtml: string, newNotes: Note[]) => void;
}

export const LawReader: React.FC<Props> = ({ htmlContent, notes, onUpdate }) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [selection, setSelection] = useState<{ x: number, y: number, text: string, range: Range } | null>(null);

  // Initial render of HTML content
  // We use a safe approach to rendering raw HTML
  useEffect(() => {
    if (contentRef.current) {
      contentRef.current.innerHTML = htmlContent;
      // Re-attach event listeners for existing highlights if we wanted interactions
    }
  }, []); // Only runs when component mounts or key changes

  // Handle text selection
  const handleMouseUp = () => {
    const windowSelection = window.getSelection();
    if (!windowSelection || windowSelection.isCollapsed) {
      setSelection(null);
      return;
    }

    const text = windowSelection.toString().trim();
    if (text.length > 0) {
      const range = windowSelection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      
      // Calculate position relative to viewport but check boundaries
      // We want the toolbar to appear above the selection
      setSelection({
        x: rect.left + (rect.width / 2),
        y: rect.top + window.scrollY - 10,
        text,
        range
      });
    }
  };

  const applyHighlight = (color: 'warm' | 'cold') => {
    if (!selection || !contentRef.current) return;

    try {
      const { range, text } = selection;
      
      // Create visual highlight wrapper
      const span = document.createElement('span');
      const highlightClass = color === 'warm' 
        ? 'bg-red-200 text-red-900 border-b-2 border-red-400' 
        : 'bg-cyan-200 text-cyan-900 border-b-2 border-cyan-400';
      
      span.className = `highlight-node ${highlightClass} px-1 rounded cursor-pointer transition-colors`;
      span.setAttribute('data-note-id', crypto.randomUUID());
      span.title = color === 'warm' ? 'Nota Quente' : 'Nota Fria';
      
      // Extract contents and wrap
      // Note: surroundContents fails if selection crosses block boundaries.
      // We'll use a safer extract/insert method or try surround first.
      try {
        range.surroundContents(span);
      } catch (e) {
        // Fallback for complex selections (just wraps the text content, might lose nested formatting)
        const documentFragment = range.extractContents();
        span.appendChild(documentFragment);
        range.insertNode(span);
      }

      // Clear selection
      window.getSelection()?.removeAllRanges();
      setSelection(null);

      // Create Note Object
      const newNote: Note = {
        id: span.getAttribute('data-note-id')!,
        text: text,
        color: color,
        createdAt: Date.now()
      };

      // Propagate changes up
      // We send back the FULL innerHTML so it's saved with the <span> tags
      onUpdate(contentRef.current.innerHTML, [...notes, newNote]);

    } catch (error) {
      console.error("Highlight error:", error);
      alert("Não foi possível destacar esta seleção (tente selecionar apenas texto dentro de um parágrafo).");
    }
  };

  const removeNote = (noteId: string) => {
    // This is complex because we need to remove the span from the HTML string.
    // Ideally we parse it, find the span, unwrap it.
    // For simplicity, we just filter the note list and let the user visually handle it later 
    // or we implement unwrapping:
    if (contentRef.current) {
      const span = contentRef.current.querySelector(`span[data-note-id="${noteId}"]`);
      if (span) {
        // Unwrap
        const parent = span.parentNode;
        while (span.firstChild) {
          parent?.insertBefore(span.firstChild, span);
        }
        parent?.removeChild(span);
        
        // Update state
        onUpdate(contentRef.current.innerHTML, notes.filter(n => n.id !== noteId));
      } else {
        // Fallback just remove from list if visual element missing
        onUpdate(contentRef.current.innerHTML, notes.filter(n => n.id !== noteId));
      }
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[500px]">
      
      {/* Content Reader */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-slate-200 relative">
        <div 
          ref={contentRef}
          onMouseUp={handleMouseUp}
          className="law-content p-8 md:p-12 overflow-y-auto max-h-[70vh] font-serif text-lg leading-relaxed text-slate-800"
          style={{ fontFamily: '"Merriweather", "Georgia", serif' }}
        />
        
        {/* Placeholder if empty */}
        {!htmlContent && (
           <div className="absolute inset-0 flex items-center justify-center text-slate-400">
             <p>Nenhum conteúdo carregado.</p>
           </div>
        )}

        {/* Floating Toolbar */}
        {selection && (
          <div 
            className="fixed z-50 flex items-center gap-2 bg-slate-900 text-white p-2 rounded-lg shadow-xl animate-in fade-in zoom-in-95"
            style={{ 
              left: selection.x, 
              top: selection.y - 60, // Position above
              transform: 'translateX(-50%)' 
            }}
          >
            <button 
              onClick={() => applyHighlight('warm')}
              className="flex flex-col items-center p-2 hover:bg-slate-700 rounded transition-colors text-red-400"
            >
              <Flame size={20} fill="currentColor" />
              <span className="text-[10px] font-bold uppercase mt-1">Quente</span>
            </button>
            <div className="w-px h-8 bg-slate-700 mx-1"></div>
            <button 
              onClick={() => applyHighlight('cold')}
              className="flex flex-col items-center p-2 hover:bg-slate-700 rounded transition-colors text-cyan-400"
            >
              <Snowflake size={20} fill="currentColor" />
              <span className="text-[10px] font-bold uppercase mt-1">Frio</span>
            </button>
            <button 
               onClick={() => setSelection(null)}
               className="ml-2 p-1 text-slate-500 hover:text-white"
            >
              <X size={16} />
            </button>
            
            {/* Arrow */}
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 rotate-45"></div>
          </div>
        )}
      </div>

      {/* Notes Sidebar */}
      <div className="w-full lg:w-80 bg-slate-50 rounded-xl border border-slate-200 flex flex-col h-[70vh]">
        <div className="p-4 border-b border-slate-200 bg-white rounded-t-xl">
           <h3 className="font-bold text-slate-700 flex items-center gap-2">
             <StickyNote size={18} /> Notas e Destaques
           </h3>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notes.length === 0 ? (
            <div className="text-center text-slate-400 py-10">
              <p className="text-sm">Selecione trechos do texto para criar notas.</p>
            </div>
          ) : (
            notes.map(note => (
              <div key={note.id} className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 group relative hover:shadow-md transition-shadow">
                 <div className={`absolute left-0 top-3 bottom-3 w-1 rounded-r ${
                   note.color === 'warm' ? 'bg-red-400' : 'bg-cyan-400'
                 }`}></div>
                 
                 <p className="text-sm text-slate-700 italic pl-3 mb-2 line-clamp-4">
                   "{note.text}"
                 </p>
                 
                 <div className="pl-3 flex justify-between items-center mt-2 border-t pt-2 border-slate-50">
                    <span className={`text-[10px] font-bold uppercase tracking-wider ${
                       note.color === 'warm' ? 'text-red-500' : 'text-cyan-600'
                    }`}>
                      {note.color === 'warm' ? 'Importante' : 'Informativo'}
                    </span>
                    <button 
                      onClick={() => removeNote(note.id)}
                      className="text-slate-300 hover:text-rose-500 transition-colors"
                      title="Remover nota"
                    >
                      <X size={14} />
                    </button>
                 </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
