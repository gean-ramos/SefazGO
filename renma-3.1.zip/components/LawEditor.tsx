
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Plus, Trash2, Edit3, List, UploadCloud, Loader2, Check, Zap, RefreshCw } from 'lucide-react';
import { Law, Card, MasteryLevel } from '../types';
import { getLawById, saveLaw } from '../services/storage';
import { ImportModal } from './ImportModal';
import { parseImportData, readFileContent } from '../utils/importHelpers';

export const LawEditor: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [law, setLaw] = useState<Law | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  
  const [isEditingCard, setIsEditingCard] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Card>>({});
  
  // Ref for hidden replacement file input
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (id) {
      const data = getLawById(id);
      if (data) {
        setLaw(data);
      } else {
        navigate('/dashboard');
      }
    }
  }, [id, navigate]);

  useEffect(() => {
    if (saveStatus === 'saved') {
      const timer = setTimeout(() => setSaveStatus('idle'), 2000);
      return () => clearTimeout(timer);
    }
  }, [saveStatus]);

  const handleSaveLawDetails = () => {
    if (law) {
      setSaveStatus('saving');
      saveLaw(law);
      setTimeout(() => setSaveStatus('saved'), 500);
    }
  };

  const handleUpdateLaw = (field: keyof Law, value: any) => {
    if (law) {
      const updatedLaw = { ...law, [field]: value };
      setLaw(updatedLaw);
    }
  };

  const handleReplaceClick = () => {
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
        fileInputRef.current.click();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (fileInputRef.current) fileInputRef.current.value = '';
    
    if (!file || !law) return;

    try {
        setIsProcessingFile(true);
        const content = await readFileContent(file);
        const result = parseImportData(content);

        if (result.cards.length === 0) {
            alert("O arquivo selecionado está vazio ou não possui questões no formato correto.");
            return;
        }

        const confirmMsg = `ATENÇÃO: SUBSTITUIÇÃO TOTAL DE CONTEÚDO\n\n` +
                           `Você está prestes a substituir TODO o conteúdo do treino "${law.title}".\n\n` +
                           `- ${law.cards.length} questões atuais serão EXCLUÍDAS.\n` +
                           `- ${result.cards.length} novas questões serão IMPORTADAS do arquivo "${file.name}".\n\n` +
                           `Deseja confirmar a substituição?`;
        
        await new Promise(resolve => setTimeout(resolve, 100));

        if (window.confirm(confirmMsg)) {
            const updatedLaw: Law = { 
                ...law, 
                cards: result.cards, 
                stats: {} 
            };
            
            setLaw(updatedLaw);
            saveLaw(updatedLaw);
            setSaveStatus('saved');
            setTimeout(() => setSaveStatus('idle'), 2000);
        }
    } catch (error) {
        console.error(error);
        alert("Erro ao ler ou processar o arquivo.");
    } finally {
        setIsProcessingFile(false);
    }
  };

  const startNewCard = () => {
    setIsEditingCard('new');
    setEditForm({
      text: '',
      isTrue: true,
      explanation: '',
      articleId: 'Art. 1º',
      mastery: MasteryLevel.EASY,
      tags: []
    });
  };

  const saveCard = () => {
    if (!law || !editForm.text) return;

    const newCard: Card = {
      id: isEditingCard === 'new' ? crypto.randomUUID() : isEditingCard!,
      text: editForm.text || '',
      isTrue: editForm.isTrue ?? true,
      explanation: editForm.explanation || '',
      articleId: editForm.articleId || 'Art. 1º',
      mastery: editForm.mastery || MasteryLevel.EASY,
      tags: editForm.tags || []
    };

    let updatedCards = [...law.cards];
    if (isEditingCard === 'new') {
      updatedCards.unshift(newCard);
    } else {
      updatedCards = updatedCards.map(c => c.id === newCard.id ? newCard : c);
    }

    const updatedLaw = { ...law, cards: updatedCards };
    setLaw(updatedLaw);
    saveLaw(updatedLaw);
    setIsEditingCard(null);
  };

  const handleBulkImport = (newCards: Card[]) => {
    if (!law) return;
    const updatedLaw = { ...law, cards: [...newCards, ...law.cards] };
    setLaw(updatedLaw);
    saveLaw(updatedLaw);
    alert(`${newCards.length} questões adicionadas com sucesso!`);
  };

  const handleImportReplace = (newCards: Card[]) => {
    if (!law) return;
    const updatedLaw: Law = { 
        ...law, 
        cards: newCards,
        stats: {} 
    };
    setLaw(updatedLaw);
    saveLaw(updatedLaw);
    setSaveStatus('saved');
  };

  const deleteCard = (cardId: string) => {
    if (!law) return;
    if (window.confirm('Tem certeza que deseja excluir esta questão?')) {
        const updatedLaw = { ...law, cards: law.cards.filter(c => c.id !== cardId) };
        setLaw(updatedLaw);
        saveLaw(updatedLaw);
    }
  };

  const editCard = (card: Card) => {
    setIsEditingCard(card.id);
    setEditForm({ ...card });
  };

  if (!law) return <div className="min-h-screen bg-neutral-900 flex items-center justify-center text-white"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-neutral-100 font-sans">
      <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".csv,.txt" />

      {/* Header Estilo Print 13 */}
      <div className="bg-black text-white sticky top-0 z-30 shadow-lg">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0 overflow-hidden">
            {/* Setinha Esquerda retornando para SubjectSessions (Print 14) */}
            <button 
              onClick={() => navigate(`/subject/${law.subjectId}`)} 
              className="p-3 -ml-3 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-2xl transition-all active:scale-90 shrink-0"
            >
              <ArrowLeft size={24} />
            </button>
            <div className="min-w-0 flex-1">
               <h1 className="font-bold text-xl truncate leading-none mb-1 block">{law.title || 'Sem Título'}</h1>
               <span className="text-[10px] text-neutral-500 uppercase font-black tracking-[0.2em] block">EDITOR DE TREINO</span>
            </div>
          </div>
          
          <div className="flex gap-3 items-center shrink-0">
            {/* Ícone de Raio Estilo Print 13 */}
            <button 
                onClick={() => navigate(`/study/${law.id}`)}
                className="w-12 h-12 flex items-center justify-center rounded-xl bg-neutral-900 border border-neutral-800 text-yellow-400 hover:bg-neutral-800 transition-all shadow-lg active:scale-95"
                title="Iniciar Treino"
            >
                <Zap size={22} fill="currentColor" />
            </button>

            {/* Ícone de Salvar Estilo Print 13 */}
            <button 
              onClick={handleSaveLawDetails}
              disabled={saveStatus === 'saving'}
              className={`w-12 h-12 flex items-center justify-center rounded-xl transition-all shadow-lg active:scale-95 ${
                saveStatus === 'saved' 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-red-700 text-white hover:bg-red-600'
              }`}
              title="Salvar Treino"
            >
              {saveStatus === 'saving' ? <Loader2 size={22} className="animate-spin" /> : 
               saveStatus === 'saved' ? <Check size={22} strokeWidth={3} /> : <Save size={22} />}
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-neutral-200 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                  <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-[0.2em] pl-1">Nome do Treino</label>
                  <div className="flex gap-3">
                      <input 
                        value={law.title}
                        onChange={(e) => handleUpdateLaw('title', e.target.value)}
                        className="w-full text-xl font-bold p-4 border border-neutral-100 rounded-2xl focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none bg-neutral-50 transition-all"
                        placeholder="Ex: Aula 01"
                      />
                      <button 
                          onClick={handleReplaceClick}
                          disabled={isProcessingFile}
                          className="p-4 bg-neutral-100 text-neutral-400 hover:bg-blue-50 hover:text-blue-600 rounded-2xl transition-all border border-transparent hover:border-blue-100 disabled:opacity-50"
                          title="Atualizar arquivo"
                      >
                          {isProcessingFile ? <Loader2 size={24} className="animate-spin" /> : <RefreshCw size={24} />}
                      </button>
                  </div>
              </div>
              <div className="space-y-3">
                  <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-[0.2em] pl-1">Descrição</label>
                  <input 
                    value={law.description}
                    onChange={(e) => handleUpdateLaw('description', e.target.value)}
                    className="w-full text-xl md:text-2xl font-bold p-5 border border-neutral-100 rounded-[2rem] focus:border-red-600 outline-none bg-neutral-50 transition-all placeholder:font-normal placeholder:text-neutral-300"
                    placeholder="Descrição do conteúdo..."
                  />
              </div>
            </div>
        </div>

        <div className="flex items-center justify-between flex-wrap gap-4 pt-4">
            <div className="flex items-center gap-4">
                <div className="bg-black text-white p-3 rounded-xl shadow-lg shadow-black/10"><List size={20} /></div>
                <h2 className="font-black text-2xl text-neutral-900 tracking-tight">Questões ({law.cards.length})</h2>
            </div>
            
            <div className="flex gap-3">
              <button 
                  onClick={() => setShowImportModal(true)}
                  className="flex items-center gap-3 px-6 py-3 bg-neutral-100 text-neutral-600 rounded-2xl text-xs font-black uppercase tracking-[0.1em] hover:bg-neutral-200 transition-all"
              >
                  <UploadCloud size={18} /> Importar
              </button>
              <button 
                  onClick={startNewCard}
                  className="flex items-center gap-3 px-6 py-3 bg-black text-white rounded-2xl text-xs font-black uppercase tracking-[0.1em] hover:bg-neutral-900 transition-all shadow-xl shadow-black/10"
              >
                  <Plus size={18} strokeWidth={3} /> Nova Questão
              </button>
            </div>
        </div>

        {isEditingCard && (
            <div className="bg-white p-8 rounded-[2.5rem] shadow-2xl border-2 border-red-600 animate-in slide-in-from-top-4 relative overflow-hidden">
                <h3 className="font-black text-red-700 mb-8 flex items-center gap-3 text-lg uppercase tracking-widest">
                    {isEditingCard === 'new' ? 'Nova Questão' : 'Editar Questão'}
                </h3>
                
                <div className="space-y-6 relative z-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                          <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider pl-1">Artigo / Referência</label>
                          <input 
                            value={editForm.articleId}
                            onChange={e => setEditForm({...editForm, articleId: e.target.value})}
                            className="w-full p-4 border border-neutral-100 rounded-2xl text-sm bg-neutral-50 focus:border-red-600 outline-none"
                            placeholder="Ex: Art. 1º"
                          />
                      </div>
                      <div className="space-y-2">
                          <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider pl-1">Dificuldade</label>
                          <select 
                              value={editForm.mastery}
                              onChange={e => setEditForm({...editForm, mastery: e.target.value as MasteryLevel})}
                              className="w-full p-4 border border-neutral-100 rounded-2xl text-sm bg-neutral-50 focus:border-red-600 outline-none appearance-none"
                          >
                              {Object.values(MasteryLevel).map(level => (
                                  <option key={level} value={level}>{level}</option>
                              ))}
                          </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider pl-1">Enunciado</label>
                      <textarea 
                          value={editForm.text}
                          onChange={e => setEditForm({...editForm, text: e.target.value})}
                          className="w-full p-5 border border-neutral-100 rounded-[2rem] text-base min-h-[120px] bg-neutral-50 focus:border-red-600 outline-none font-medium"
                          placeholder="Digite a afirmação..."
                      />
                    </div>

                    <div className="flex gap-6 p-5 bg-neutral-50 rounded-[1.5rem] border border-neutral-100">
                      <label className="flex items-center gap-3 cursor-pointer group">
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${editForm.isTrue === true ? 'border-emerald-500 bg-emerald-50' : 'border-neutral-300'}`}>
                              {editForm.isTrue === true && <div className="w-3 h-3 bg-emerald-500 rounded-full" />}
                          </div>
                          <input type="radio" checked={editForm.isTrue === true} onChange={() => setEditForm({...editForm, isTrue: true})} className="hidden" />
                          <span className={`text-xs font-black tracking-widest ${editForm.isTrue === true ? 'text-emerald-700' : 'text-neutral-400'}`}>CERTO</span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer group">
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${editForm.isTrue === false ? 'border-red-500 bg-red-50' : 'border-neutral-300'}`}>
                              {editForm.isTrue === false && <div className="w-3 h-3 bg-red-500 rounded-full" />}
                          </div>
                          <input type="radio" checked={editForm.isTrue === false} onChange={() => setEditForm({...editForm, isTrue: false})} className="hidden" />
                          <span className={`text-xs font-black tracking-widest ${editForm.isTrue === false ? 'text-red-700' : 'text-neutral-400'}`}>ERRADO</span>
                      </label>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider pl-1">Fundamentação Legal</label>
                      <textarea 
                          value={editForm.explanation}
                          onChange={e => setEditForm({...editForm, explanation: e.target.value})}
                          className="w-full p-5 border border-neutral-100 rounded-[2rem] text-sm min-h-[120px] bg-neutral-50 focus:border-red-600 outline-none"
                          placeholder="Justificativa..."
                      />
                    </div>

                    <div className="flex justify-end gap-3 pt-6 border-t border-neutral-100">
                      <button onClick={() => setIsEditingCard(null)} className="px-8 py-3 text-neutral-400 font-black text-xs uppercase tracking-widest hover:text-neutral-600">Cancelar</button>
                      <button onClick={saveCard} className="px-10 py-3 bg-red-700 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-red-800 shadow-xl shadow-red-900/10 active:scale-95 transition-all">Salvar Questão</button>
                    </div>
                </div>
            </div>
        )}

        <div className="space-y-4 pb-24">
            {law.cards.map((card) => (
            <div key={card.id} className="bg-white p-6 rounded-[2rem] border border-neutral-200 hover:border-red-200 hover:shadow-xl hover:shadow-neutral-200/40 transition-all group">
                <div className="flex justify-between items-start gap-6">
                <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                    <span className="text-[10px] font-black text-neutral-400 bg-neutral-50 px-3 py-1.5 rounded-lg uppercase tracking-widest">
                        {card.articleId}
                    </span>
                    <span className={`text-[10px] font-black px-3 py-1.5 rounded-lg uppercase tracking-widest border ${card.isTrue ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-red-50 text-red-700 border-red-100'}`}>
                        {card.isTrue ? 'CERTO' : 'ERRO'}
                    </span>
                    <span className="text-[10px] font-black text-neutral-400 border border-neutral-100 px-3 py-1.5 rounded-lg uppercase tracking-widest ml-auto">
                        {card.mastery}
                    </span>
                    </div>
                    <p className="text-base text-neutral-800 line-clamp-2 font-bold leading-relaxed">{card.text}</p>
                </div>
                <div className="flex flex-col gap-2">
                    <button onClick={() => editCard(card)} className="p-3 text-neutral-400 hover:bg-black hover:text-white rounded-2xl transition-all"><Edit3 size={18} /></button>
                    <button onClick={() => deleteCard(card.id)} className="p-3 text-neutral-400 hover:bg-red-600 hover:text-white rounded-2xl transition-all"><Trash2 size={18} /></button>
                </div>
                </div>
            </div>
            ))}
        </div>
      </main>

      {showImportModal && (
        <ImportModal onClose={() => setShowImportModal(false)} onImport={handleBulkImport} onReplace={handleImportReplace} />
      )}
    </div>
  );
};
