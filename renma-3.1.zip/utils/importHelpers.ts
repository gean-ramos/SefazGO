
import { Card, MasteryLevel } from '../types';

export interface ImportResult {
  cards: Card[];
  errors: string[];
  successCount: number;
}

export const parseImportData = (rawData: string): ImportResult => {
  const lines = rawData.trim().split(/\r\n|\n/);
  const cards: Card[] = [];
  const errors: string[] = [];

  // Detect delimiter (Tab for Excel paste, Semicolon or Comma for CSV)
  const firstLine = lines[0] || '';
  let delimiter = ',';
  if (firstLine.includes('\t')) delimiter = '\t';
  else if (firstLine.includes(';')) delimiter = ';';

  lines.forEach((line, index) => {
    if (!line.trim()) return;

    // Basic CSV/TSV parsing (does not handle quoted strings with newlines perfectly, but sufficient for this use case)
    const columns = line.split(delimiter).map(c => c.trim());

    // Expected Format: Question | Answer (V/F) | Explanation | Reference
    if (columns.length < 2) {
      errors.push(`Linha ${index + 1}: Formato inválido. Mínimo de 2 colunas necessárias.`);
      return;
    }

    const text = columns[0];
    const answerRaw = columns[1].toUpperCase();
    const explanation = columns[2] || 'Sem explicação cadastrada.';
    const articleId = columns[3] || 'Geral';

    // Parse Boolean
    let isTrue = false;
    if (['V', 'VERDADEIRO', 'CERTO', 'C', 'TRUE', '1', 'YES'].includes(answerRaw)) {
      isTrue = true;
    } else if (['F', 'FALSO', 'ERRADO', 'E', 'FALSE', '0', 'NO'].includes(answerRaw)) {
      isTrue = false;
    } else {
      errors.push(`Linha ${index + 1}: Gabarito inválido '${columns[1]}'. Use V ou F.`);
      return;
    }

    cards.push({
      id: crypto.randomUUID(),
      text,
      isTrue,
      explanation,
      articleId,
      mastery: MasteryLevel.EASY,
      tags: ['Importado']
    });
  });

  return {
    cards,
    errors,
    successCount: cards.length
  };
};

export const readFileContent = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = (e) => reject(e);
    reader.readAsText(file);
  });
};