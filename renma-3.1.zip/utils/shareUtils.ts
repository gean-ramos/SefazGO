import LZString from 'lz-string';
import { Law } from '../types';

export const generateShareLink = (law: Law): string => {
  // 1. Optimize payload: Remove heavy HTML content
  // We keep sourceUrl so the receiver can re-fetch the content
  const payload: Partial<Law> = {
    ...law,
    id: crypto.randomUUID(), // Generate new ID for the receiver
    content: undefined, // Too large for URL
    htmlContent: undefined, // Too large for URL
    title: `${law.title} (Compartilhado)`
  };

  // 2. Compress
  const jsonString = JSON.stringify(payload);
  const compressed = LZString.compressToEncodedURIComponent(jsonString);

  // 3. Construct URL
  const baseUrl = window.location.href.split('#')[0];
  return `${baseUrl}#/share?data=${compressed}`;
};

export const parseShareLink = (searchParams: URLSearchParams): Law | null => {
  const data = searchParams.get('data');
  if (!data) return null;

  try {
    const decompressed = LZString.decompressFromEncodedURIComponent(data);
    if (!decompressed) return null;
    
    const law = JSON.parse(decompressed) as Law;
    
    // Validate basic structure
    if (!law.title || !Array.isArray(law.cards)) {
      throw new Error("Dados inválidos");
    }

    return {
      ...law,
      createdAt: Date.now()
    };
  } catch (error) {
    console.error("Error parsing share link:", error);
    return null;
  }
};