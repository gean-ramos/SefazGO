import { Card, MasteryLevel } from './types';

// Mock data based on Lei 1.254/96 (ICMS)
export const MOCK_CARDS: Card[] = [
  {
    id: 'c1',
    articleId: 'Art. 1º',
    text: 'A disposição sobre o ICMS no Distrito Federal fundamenta-se na competência tributária prevista na Constituição e na norma complementar que rege o imposto.',
    isTrue: true,
    explanation: 'Art. 1º Esta Lei dispõe quanto ao Imposto sobre Operações Relativas à Circulação de Mercadorias e sobre Prestações de Serviços de Transporte Interestadual e Intermunicipal e de Comunicação - ICMS, com base no inciso II do art. 155 da Constituição da República Federativa do Brasil.',
    mastery: MasteryLevel.HARD,
    tags: ['SR1799', 'Lei 1.254', 'Constitucional']
  },
  {
    id: 'c2',
    articleId: 'Art. 2º',
    text: 'O fato gerador do ICMS ocorre apenas na saída física da mercadoria do estabelecimento comercial, desconsiderando a transmissão de propriedade sem movimentação física.',
    isTrue: false,
    explanation: 'Art. 2º Ocorre o fato gerador do imposto: I - na saída de mercadoria de estabelecimento de contribuinte, ainda que para outro estabelecimento do mesmo titular.',
    mastery: MasteryLevel.EASY,
    tags: ['Fato Gerador', 'Lei 1.254']
  },
  {
    id: 'c3',
    articleId: 'Art. 3º',
    text: 'A prestação de serviço de transporte intramunicipal está sujeita à incidência do ICMS, conforme regulamentação do Distrito Federal.',
    isTrue: false,
    explanation: 'O ICMS incide sobre prestações de serviços de transporte interestadual e intermunicipal. O transporte intramunicipal (dentro do mesmo município) é competência do ISS (Imposto Sobre Serviços).',
    mastery: MasteryLevel.MEDIUM,
    tags: ['Competência', 'ISS vs ICMS']
  },
  {
    id: 'c4',
    articleId: 'Art. 1º',
    text: 'O ICMS é um imposto cumulativo, incidindo em todas as etapas da cadeia de circulação sem possibilidade de compensação.',
    isTrue: false,
    explanation: 'O ICMS é um imposto não-cumulativo, compensando-se o que for devido em cada operação relativa à circulação de mercadorias ou prestação de serviços com o montante cobrado nas anteriores.',
    mastery: MasteryLevel.LITERAL,
    tags: ['Princípios', 'Não-Cumulatividade']
  },
  {
    id: 'c5',
    articleId: 'Art. 5º',
    text: 'A isenção ou não-incidência, salvo determinação em contrário da legislação, não implicará crédito para compensação com o montante devido nas operações ou prestações seguintes.',
    isTrue: true,
    explanation: 'Art. 5º A isenção ou não-incidência, salvo determinação em contrário da legislação: I - não implicará crédito para compensação com o montante devido nas operações ou prestações seguintes;',
    mastery: MasteryLevel.ADVANCED,
    tags: ['Isenção', 'Crédito']
  }
];

export const AVAILABLE_ARTICLES = [
  { id: 'Art. 1º', count: 12 },
  { id: 'Art. 2º', count: 9 },
  { id: 'Art. 3º', count: 16 },
  { id: 'Art. 4º', count: 5 },
  { id: 'Art. 5º', count: 8 },
];